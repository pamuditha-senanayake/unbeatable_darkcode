"""Anchor agent: a plain LLM given the raw observation (the "vanilla GPT" baseline).

Needs an OpenAI-compatible endpoint. Configure with environment variables so every
team hits the SAME gateway and model (fairness + cost control):

    ARENA_LLM_BASE_URL   e.g. https://openrouter.ai/api/v1  or your LiteLLM proxy
    ARENA_LLM_API_KEY    the key for that gateway
    ARENA_LLM_MODEL      e.g. openai/gpt-4o-mini

If the endpoint is unreachable the agent falls back to a random legal move rather
than crashing, so a flaky gateway degrades play instead of forfeiting the match.

Calibration aid: when ARENA_LLM_USAGE_LOG names a file, every call appends one JSON line
{"game_id", "episode", "pid", "model", "prompt_tokens", "completion_tokens", "seconds"} to it, so
tokens per episode can be counted on a laptop even when the gateway does not log the key in use.
"""
import json
import os
import re
import time

from random_agent import Agent as RandomAgent

SYSTEM_PROMPT = ("You are a competitive game player. Read the game instructions carefully, think briefly, "
                 "and finish your reply with your action(s) in the required square-bracket format, e.g. [col 3] "
                 "or [assign T1 J3 Solna] [wait]. Keep any reasoning short; the brackets are what counts.")


class Agent:
    def __init__(self):
        self.fallback = RandomAgent()
        self.model = os.environ.get("ARENA_LLM_MODEL", "arena-default")
        # Client timeout just under the arena's 45 s per-move limit (it was 24 s against a 30 s limit and
        # lost ~12% of moves under load). ARENA_LLM_REASONING_EFFORT ("minimal" | "low" | "medium" | "high")
        # is passed to reasoning models; the GPT-5 tiers otherwise spend hundreds of output tokens
        # thinking about a two-word reply (docs/game-design-v2.md). Unset = the model's default.
        self.timeout = float(os.environ.get("ARENA_LLM_TIMEOUT", "40"))
        self.reasoning_effort = os.environ.get("ARENA_LLM_REASONING_EFFORT") or None
        self.usage_log = os.environ.get("ARENA_LLM_USAGE_LOG") or None
        self.game_id, self.episode = None, 0
        self.client = None
        try:
            from openai import OpenAI
            self.client = OpenAI(base_url=os.environ.get("ARENA_LLM_BASE_URL") or None,
                                 api_key=os.environ.get("ARENA_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY"),
                                 timeout=self.timeout, max_retries=0)
        except Exception as e:  # missing package or key -> we will fall back to random
            self.init_error = str(e)

    def reset(self, game_id: str, player_id: int):
        self.fallback.reset(game_id, player_id)
        self.game_id, self.episode = game_id, self.episode + 1

    def __call__(self, observation: str) -> str:
        if self.client is None:
            return self.fallback(observation)
        try:
            # Reasoning models spend part of max_tokens thinking before any text appears; 400 was enough
            # to forfeit on DispatchDesk (Opus 5 through the gateway returned no brackets at all).
            extra = {"reasoning_effort": self.reasoning_effort} if self.reasoning_effort else {}
            t0 = time.perf_counter()
            resp = self.client.chat.completions.create(
                model=self.model, max_tokens=2000, temperature=0.2,
                messages=[{"role": "system", "content": SYSTEM_PROMPT}, {"role": "user", "content": observation}],
                **extra)
            self._log_usage(resp, time.perf_counter() - t0)
            text = (resp.choices[0].message.content or "").strip()
            # Keep only bracketed actions so chain-of-thought never confuses the parser. Multi-command
            # games (DispatchDesk) take all of them; single-action games only ever read the last one.
            actions = re.findall(r"\[[^\[\]]{1,40}\]", text)
            if not actions:
                return self.fallback(observation)   # a legal move beats a forfeit for an anchor
            return " ".join(actions[-5:])
        except Exception:
            return self.fallback(observation)

    def _log_usage(self, resp, seconds: float) -> None:
        if not self.usage_log:
            return
        try:
            u = getattr(resp, "usage", None)
            row = {"game_id": self.game_id, "episode": self.episode, "pid": os.getpid(),
                   "model": getattr(resp, "model", None) or self.model,
                   "prompt_tokens": getattr(u, "prompt_tokens", None),
                   "completion_tokens": getattr(u, "completion_tokens", None),
                   "seconds": round(seconds, 2)}
            with open(self.usage_log, "a", encoding="utf-8") as f:
                f.write(json.dumps(row) + chr(10))
        except Exception:
            pass                                    # a calibration aid must never cost a move
