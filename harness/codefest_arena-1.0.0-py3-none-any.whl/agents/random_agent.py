"""Anchor agent: uniformly random *legal* moves. Every team should beat this."""
import random

from common import (c4_legal_columns, dd_parse_jobs, dd_parse_techs, dd_travel, detect_game,
                    parse_c4_board, parse_mastermind_history, parse_mastermind_params, parse_nim_piles)


class Agent:
    def __init__(self):
        self.rng = random.Random()

    def reset(self, game_id: str, player_id: int):
        self.game_id, self.player_id = game_id, player_id

    def __call__(self, observation: str) -> str:
        game = detect_game(observation)
        if game == "dispatchdesk":
            return self._dispatchdesk(observation)
        if game == "connectfour":
            board = parse_c4_board(observation)
            cols = c4_legal_columns(board) if board else list(range(7))
            return f"[col {self.rng.choice(cols)}]"
        if game == "nim":
            piles = parse_nim_piles(observation) or [1]
            idx = self.rng.choice([i for i, p in enumerate(piles) if p > 0])
            return f"[{idx} {self.rng.randint(1, piles[idx])}]"
        if game == "mastermind":
            length, maxn, dup = parse_mastermind_params(observation)
            tried = {tuple(g) for g, _, _ in parse_mastermind_history(observation)}
            for _ in range(200):
                guess = self.rng.choices(range(1, maxn + 1), k=length) if dup else self.rng.sample(range(1, maxn + 1), k=length)
                if tuple(guess) not in tried:
                    break
            return "[" + " ".join(map(str, guess)) + "]"
        if game == "tictactoe":
            return f"[{self.rng.randint(0, 8)}]"
        return "[0]"

    def _dispatchdesk(self, obs: str) -> str:
        """Random commands about random jobs, always closed with [wait].

        [wait] is always accepted, so the reply can never be an invalid move however
        badly the rest of it is aimed - which is what makes this a usable smoke agent.
        """
        open_jobs = [j for j in dd_parse_jobs(obs) if j["status"] == "unassigned"]
        techs = dd_parse_techs(obs)
        zones = list(dd_travel(obs)) or ["Depot"]
        cmds = []
        for _ in range(self.rng.randint(0, 3)):
            if not open_jobs:
                break
            j = self.rng.choice(open_jobs)
            verb = self.rng.choice(["assign", "assign", "ask", "merge", "ignore"])
            others = [o for o in open_jobs if o["jid"] != j["jid"]]
            if verb == "assign" and techs:
                cmds.append(f"[assign {self.rng.choice(techs)['tid']} {j['jid']} {self.rng.choice(zones)}]")
            elif verb == "ask":
                cmds.append(f"[ask {j['jid']} {self.rng.choice(['location', 'problem', 'urgency'])}]")
            elif verb == "merge" and others:
                cmds.append(f"[merge {j['jid']} {self.rng.choice(others)['jid']}]")
            else:
                cmds.append(f"[ignore {j['jid']}]")
        cmds.append("[wait]")
        return " ".join(cmds)
