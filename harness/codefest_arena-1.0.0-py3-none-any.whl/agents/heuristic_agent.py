"""Anchor agent: simple hand-written strategies, no LLM.

ConnectFour:  take a winning move, else block the opponent's winning move, else prefer the centre.
Nim:          optimal play via nim-sum (XOR) - unbeatable from a winning position.
Mastermind:   guess a random code consistent with all feedback so far (a light version of Knuth).
DispatchDesk: keyword matching on the ticket text - reads the words, not the situation.
"""
import copy
import random

from common import (c4_drop, c4_legal_columns, c4_my_symbol, c4_wins_at, dd_parse_directory,
                    dd_parse_jobs, dd_parse_messages, dd_parse_techs, dd_travel, detect_game,
                    mastermind_feedback, parse_c4_board, parse_mastermind_history,
                    parse_mastermind_params, parse_nim_piles)

# ------------------------------------------------------------- DispatchDesk word banks
# Deliberately shallow: the first matching word wins. The generator writes half of the
# tickets so that the obvious words point at the wrong skill, and hides most P3s behind a
# negated urgency word ("not urgent", "no need to hurry"), so this anchor misreads a fair
# share of them by construction. Beating it means reading the situation, not the vocabulary.
DD_SKILL_WORDS = {
    "refrigeration": ["cold room", "freezer", "fridge", "refrigerat", "compressor", "chiller",
                      "cold storage", "ice cream", "vaccine", "cabinet"],
    "lift": ["lift", "elevator", "hoist", "cabin", "shaft", "platform"],
    "plumbing": ["pipe", "toilet", "hot water", "valve", "leak", "drain", "water on the floor",
                 "dishwasher", "sprinkler", "burst", "puddle"],
    "IT": ["network", "wifi", "switch", "router", "access-point", "internet", "server",
           "point-of-sale", "tills", "screen", "no connection", "card reader", "dashboard"],
    "HVAC": ["air conditioning", "air con", "ventilation", "heat pump", "thermostat", "the ac",
             "stuffy", "roasting", "boiling", "climate", "temperature"],
    "electrical": ["breaker", "socket", "sparking", "distribution board", "switchboard", "phase",
                   "power", "electric", "lights", "supply", "panel", "buzzing"],
}
DD_P1_WORDS = ["urgent", "critical", "right now", "within the hour", "hurry", "someone is inside",
               "standing still", "before they are lost", "only way up"]
DD_P3_WORDS = ["no rush", "low priority", "whenever", "not an emergency", "end of day is fine",
               "before the end of the day", "just logging it"]
DD_DUP_WORDS = ["hi again", "following up", "2nd message", "re:", "still nobody", "any update",
                "is this being handled", "has anyone been dispatched", "same building",
                "still ongoing", "wrote earlier"]
DD_NOISE_WORDS = ["invoice", "wrong number", "sandwiches", "no action needed", "nothing broken",
                  "nothing is broken", "no fault to report", "technician visited", "for your records",
                  "fixed it yesterday", "expires next month", "closing the loop", "sorted it out",
                  "email a quote", "nothing to fix"]


class Agent:
    def __init__(self):
        self.rng = random.Random(1234)

    def reset(self, game_id: str, player_id: int):
        self.player_id = player_id

    # ------------------------------------------------------------ dispatch
    def __call__(self, observation: str) -> str:
        game = detect_game(observation)
        if game == "connectfour":
            return self._connect_four(observation)
        if game == "nim":
            return self._nim(observation)
        if game == "mastermind":
            return self._mastermind(observation)
        if game == "dispatchdesk":
            return self._dispatchdesk(observation)
        return "[0]"

    # -------------------------------------------------------- Connect Four
    def _connect_four(self, obs: str) -> str:
        board = parse_c4_board(obs)
        if board is None:
            return "[col 3]"
        me = c4_my_symbol(obs)
        opp = "O" if me == "X" else "X"
        legal = c4_legal_columns(board)
        for sym in (me, opp):                      # 1) win now, 2) block their win
            for c in legal:
                b = copy.deepcopy(board)
                r, _ = c4_drop(b, c, sym)
                if c4_wins_at(b, r, c):
                    return f"[col {c}]"
        # 3) avoid giving the opponent a win directly on top of our move
        safe = []
        for c in legal:
            b = copy.deepcopy(board)
            c4_drop(b, c, me)
            gives_win = False
            if b[0][c] == ".":
                b2 = copy.deepcopy(b)
                r2, _ = c4_drop(b2, c, opp)
                gives_win = c4_wins_at(b2, r2, c)
            if not gives_win:
                safe.append(c)
        pool = safe or legal
        centre = (len(board[0]) - 1) / 2
        pool.sort(key=lambda c: abs(c - centre))
        return f"[col {pool[0]}]"

    # --------------------------------------------------------------- Nim
    def _nim(self, obs: str) -> str:
        piles = parse_nim_piles(obs)
        if not piles:
            return "[0 1]"
        x = 0
        for p in piles:
            x ^= p
        if x != 0:
            for i, p in enumerate(piles):
                target = p ^ x
                if target < p:
                    return f"[{i} {p - target}]"
        # losing position: take 1 from the biggest pile and hope
        i = max(range(len(piles)), key=lambda k: piles[k])
        return f"[{i} 1]"

    # -------------------------------------------------------- Mastermind
    def _mastermind(self, obs: str) -> str:
        length, maxn, dup = parse_mastermind_params(obs)
        hist = parse_mastermind_history(obs)
        tried = {tuple(g) for g, _, _ in hist}
        for _ in range(20000):
            cand = self.rng.choices(range(1, maxn + 1), k=length) if dup else self.rng.sample(range(1, maxn + 1), k=length)
            if tuple(cand) in tried:
                continue
            if all(mastermind_feedback(cand, g) == (b, w) for g, b, w in hist):
                return "[" + " ".join(map(str, cand)) + "]"
        cand = self.rng.sample(range(1, maxn + 1), k=length)
        return "[" + " ".join(map(str, cand)) + "]"

    # ------------------------------------------------------- DispatchDesk
    def _dispatchdesk(self, obs: str) -> str:
        """Classify every open ticket by keyword, then send the nearest qualified technician.

        The reply is spent in this order: close non-requests, merge repeats, dispatch by
        guessed priority, ask for a site only when nothing in the text names one. There is
        no look-ahead and no notion of the SLA clock. Four commands at most plus a closing
        [wait], so a batch of rejected commands can never add up to an invalid move.
        """
        jobs = dd_parse_jobs(obs)
        techs = dd_parse_techs(obs)
        travel = dd_travel(obs)
        directory = dd_parse_directory(obs)
        msgs = dd_parse_messages(obs)
        for t in techs:
            t["load"] = len(t["queue"]) + (0 if t["activity"] == "idle" else 1)

        ignores, merges, assigns, asks = [], [], [], []
        for j in [j for j in jobs if j["status"] == "unassigned"]:
            text = msgs.get(j["jid"], {}).get("text", "")
            blob = (j["sender"] + " " + text).lower()
            cust = self._dd_customer(blob, directory)

            if self._dd_any(blob, DD_NOISE_WORDS):
                ignores.append("[ignore %s]" % j["jid"])
                continue
            if self._dd_any(blob, DD_DUP_WORDS):
                orig = self._dd_original(j, cust, jobs, msgs, directory)
                if orig:
                    merges.append("[merge %s %s]" % (j["jid"], orig))
                    continue

            zone = j["zone"] or (cust["zone"] if cust else self._dd_zone_in_text(blob, travel))
            if zone is None:
                if "[ask %s " % j["jid"] not in obs:
                    asks.append("[ask %s location]" % j["jid"])
                continue
            prio = j["prio"] or self._dd_prio(blob)
            t = self._dd_pick(techs, j["skill"] or self._dd_skill(blob), zone, travel)
            if t is None:
                continue
            assigns.append((prio, j["minute"], "[assign %s %s %s]" % (t["tid"], j["jid"], zone)))
            t["load"] += 1
            t["zone"], t["dest"] = zone, None

        assigns.sort(key=lambda a: (a[0], a[1]))
        cmds = ignores + merges + [a[2] for a in assigns] + asks
        return " ".join(cmds[:4] + ["[wait]"])

    @staticmethod
    def _dd_any(blob, words) -> bool:
        return any(w in blob for w in words)

    @staticmethod
    def _dd_customer(blob, directory):
        """The first customer whose name or nickname appears in the sender line or the text."""
        for c in directory:
            if c["name"].lower() in blob:
                return c
        for c in directory:
            if any(a.lower() in blob for a in c["aliases"]):
                return c
        return None

    @staticmethod
    def _dd_zone_in_text(blob, travel):
        """A bare zone name in the text. Sometimes it is the site, sometimes a decoy."""
        for z in travel:
            if z != "Depot" and z.lower() in blob:
                return z
        return None

    @staticmethod
    def _dd_skill(blob):
        for skill, words in DD_SKILL_WORDS.items():
            if any(w in blob for w in words):
                return skill
        return "electrical"

    @staticmethod
    def _dd_prio(blob) -> int:
        if any(w in blob for w in DD_P1_WORDS):
            return 1
        if any(w in blob for w in DD_P3_WORDS):
            return 3
        return 2

    def _dd_original(self, dup, cust, jobs, msgs, directory):
        """The earlier ticket this one looks like a repeat of, or None if we cannot tell."""
        if cust is None:
            return None
        for j in jobs:
            if j["jid"] == dup["jid"] or j["minute"] > dup["minute"]:
                continue
            blob = (j["sender"] + " " + msgs.get(j["jid"], {}).get("text", "")).lower()
            if self._dd_customer(blob, directory) is cust:
                return j["jid"]
        return None

    @staticmethod
    def _dd_pick(techs, skill, zone, travel):
        """The qualified technician with the lightest queue, nearest first."""
        cands = [t for t in techs if skill in t["skills"] and not t["off_shift"]]
        if not cands:
            return None

        def cost(t):
            here = t["zone"] or t["dest"] or zone
            return t["load"] * 45 + travel.get(here, {}).get(zone, 30)

        return min(cands, key=cost)
