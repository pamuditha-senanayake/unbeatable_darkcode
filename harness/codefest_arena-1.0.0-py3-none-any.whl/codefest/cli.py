"""The `codefest` command.

    codefest play                    play one shift with agent.py and draw it
    codefest validate                the competition's game, 45 s limit and fault rule, on your laptop
    codefest replay                  draw a shift without re-reading the output
    codefest compare                 your agent next to the reference policies

Everything defaults to `agent.py` in the current folder, the newest level in this install and seed 7, so the
common case is one word. Output goes to `replays/` next to your agent.

`validate` is the one that matters: same game, same 45 second limit, same fault rule as the
competition. The one thing it cannot copy is the language model, which is only reachable from
inside the competition cluster. If your agent calls a model, that call fails here, so what you
are testing locally is your fallback path. Push, then request a practice run from your team
workspace to see your agent with the model.
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

def default_game() -> str:
    """The newest DispatchDesk level registered in this install (DispatchDesk-L<n> with the highest n)."""
    import re
    import arena.games  # noqa: F401  registers the env ids
    from textarena.envs.registration import ENV_REGISTRY
    levels = [(int(m.group(1)), env_id) for env_id in ENV_REGISTRY
              for m in [re.fullmatch(r"DispatchDesk-L(\d+)", env_id)] if m]
    if not levels:
        raise SystemExit("no DispatchDesk level is registered in this install; "
                         "reinstall the wheel from harness/ (see README.md)")
    return max(levels)[1]


def _registered_games() -> list:
    """Every env id this install can play, newest level last."""
    import arena.games  # noqa: F401  registers the env ids
    from textarena.envs.registration import ENV_REGISTRY
    return sorted(env_id for env_id in ENV_REGISTRY if env_id.startswith("DispatchDesk-"))


GAME = default_game()
SEED = 7
TIMEOUT = 45.0                 # the competition's per-reply limit
FAULT_ACTION = "[wait]"        # a late or raising reply is played as this
MAX_FAULTS = 3                 # the fourth fault in one shift forfeits it

REFERENCES = ["dd_careful", "dd_eager", "dd_asker", "heuristic_agent", "random_agent"]


def _fail(msg: str) -> "int":
    print(f"\n{msg}", file=sys.stderr)
    return 2


def _agent_path(raw: str) -> Path:
    p = Path(raw).resolve()
    if not p.is_file():
        raise SystemExit(f"no such file: {p}\n"
                         f"Run this from the folder that holds your agent.py, or pass the path.")
    return p


def _reference_path(name: str) -> Path:
    import importlib.util
    spec = importlib.util.find_spec(f"agents.{name}")
    if spec is None or not spec.origin:
        raise SystemExit(f"the reference policy {name} is not in this install")
    return Path(spec.origin)


def _out_path(args, who: str) -> Path:
    """One file per (agent, game, seed), so playing a reference does not overwrite your own."""
    if getattr(args, "out", None):
        return Path(args.out).resolve()
    return Path.cwd() / "replays" / f"{who}_{args.game}_seed{args.seed}.html"


# docs/game-rules.md reference table (mean over many seeds): planner ceiling (not a legal agent),
# careful rule-based reference, keyword anchor. Levels 4 and 5 read the level-3 row until the rules
# sheet gains theirs.
REFERENCE = {
    "DispatchDesk-L1": (0.72, 0.50, 0.44),
    "DispatchDesk-L2": (0.67, 0.35, 0.18),
    "DispatchDesk-L3": (0.67, 0.27, 0.10),
}


def _reference(game: str) -> tuple:
    return REFERENCE.get(game, REFERENCE["DispatchDesk-L3"])


def _score_words(score: float, game: str = "") -> str:
    """Say what a number means on THIS level. Students see this before they see the rules sheet."""
    planner, careful, keyword = _reference(game or GAME)
    if score <= 0.0:
        return "nothing finished, or everything it earned was eaten by costs"
    if score < keyword / 2:
        return "about as good as dispatching on the first word you recognise"
    if score < keyword + 0.02:
        return f"around the keyword-matching anchor bot (about {keyword:.2f} on this level)"
    if score < careful:
        return f"between the anchor bot and the careful rule-based reference (about {careful:.2f} here)"
    if score < careful + 0.15:
        return f"at or above the careful rule-based reference ({careful:.2f} here), which is a good place to be"
    if score < planner - 0.05:
        return f"well above the careful reference on this shift (planner ceiling {planner:.2f}); single shifts vary, run compare over several seeds"
    return f"at the perfect-information planner ceiling ({planner:.2f}) on this shift; single shifts vary a lot, run compare over several seeds"


# ------------------------------------------------------------------------------------- play

def cmd_play(args) -> int:
    from arena.games.dispatchdesk.replay import record, write_html

    agent = _agent_path(args.agent)
    print(f"playing {args.game} seed {args.seed} with {agent.name} ...")
    t0 = time.time()
    try:
        trace = record(args.game, args.seed, agent, agent_name=agent.stem)
    except Exception as e:                       # noqa: BLE001  a student's agent, not our code
        import traceback
        traceback.print_exc()
        return _fail(f"your agent raised {type(e).__name__}: {e}\n"
                     f"In the competition that reply is played as [wait] and counts as a fault. "
                     f"Four faults in one shift forfeit it.")
    final = trace["final"]
    took = time.time() - t0

    print(f"\n  score      {final['score']:.3f}   ({_score_words(final['score'], args.game)})")
    print(f"  earned     {final['earned']:.0f} of {final['max_value']:.0f} on offer")
    costs = final.get("costs") or {}
    print("  costs      " + ", ".join(f"{k} {v:.0f}" for k, v in costs.items()))
    print(f"  jobs       {final['done']} of {final['real']} finished, {final['on_time']} within SLA")
    print(f"  took       {took:.1f}s")

    if not args.no_replay:
        out = write_html(trace, _out_path(args, agent.stem))
        print(f"\n  replay     {out}")
        print("             open it in a browser and scrub the clock")
    return 0


# --------------------------------------------------------------------------------- validate

def cmd_validate(args) -> int:
    from arena.loader import AgentProcess
    from arena.runner import play_match

    agent = _agent_path(args.agent)
    handle = AgentProcess("candidate", str(agent))
    print(f"checking {agent.name} with the competition's game, time limit and fault rule")
    print(f"  game {args.game}, seed {args.seed}, {TIMEOUT:.0f}s per reply, "
          f"{MAX_FAULTS + 1} faults forfeit\n")
    try:
        if not handle.start():
            print("FAIL  your agent did not import or Agent() did not construct:\n")
            print(handle.init_error)
            print("\nRESULT: NOT READY")
            return 1
        print("OK    imports, and Agent() constructs")
        r = play_match(args.game, {0: handle}, seed=args.seed, match_id="validate",
                       per_move_timeout=TIMEOUT, fault_action=FAULT_ACTION,
                       max_faults=MAX_FAULTS, render=args.render)
    finally:
        handle.stop()

    outcome = r.outcomes[0]
    times = r.move_times[0] or [0.0]
    faults = r.faults.get(0, 0)
    ok = not outcome.startswith("forfeit")

    if ok:
        print(f"OK    played all {r.turns} replies, score {r.rewards[0]:.3f}")
    else:
        print(f"FAIL  stopped after {r.turns} replies, {outcome}, score {r.rewards[0]:.3f}")
    print(f"      slowest reply {max(times):.2f}s, average {sum(times) / len(times):.2f}s, "
          f"limit {TIMEOUT:.0f}s")
    if faults:
        print(f"      {faults} fault(s): a reply was late or raised and was played as [wait]")
    if r.reasons.get(0):
        print(f"      {r.reasons[0][:200]}")

    if ok:
        print(f"\nRESULT: READY TO SUBMIT   (score {r.rewards[0]:.3f}, "
              f"{_score_words(r.rewards[0], args.game)})")
        if r.rewards[0] <= 0.0 and not faults:
            print("      0.000 with no faults can also mean your agent answered [wait] every tick because its\n"
                  "      own try/except swallowed an error. Run `codefest play --render` and check that your\n"
                  "      commands were accepted.")
    else:
        print("\nRESULT: NOT READY")
        print(_advice(outcome))
    if max(times) > TIMEOUT * 0.5:
        print(f"\nWarning: your slowest reply took {max(times):.1f}s of the {TIMEOUT:.0f}s limit. "
              f"A competition pod is slower than your laptop.")
    return 0 if ok else 1


def _advice(outcome: str) -> str:
    return {
        "forfeit-timeout": "  A reply took longer than the limit four times. Make the slow path "
                           "faster, or answer with [wait] when you are running out of time.",
        "forfeit-crash": "  Your agent raised four times. Wrap the risky part in try/except and "
                         "return [wait] if it fails.",
        "forfeit-invalid": "  Two replies in a row had no accepted command. End every reply with "
                           "[wait]: it is always accepted, and it costs nothing.",
        "forfeit-dead": "  Your agent process died. Look for something that exits, or for memory "
                        "the machine did not have.",
    }.get(outcome, "  Read the lines above, then docs/game-rules.md.")


# ----------------------------------------------------------------------------------- replay

def cmd_replay(args) -> int:
    from arena.games.dispatchdesk.replay import record, write_html

    agent = None if args.agent.lower() == "none" else _agent_path(args.agent)
    trace = record(args.game, args.seed, agent, agent_name=agent.stem if agent else "wait-only")
    out = write_html(trace, _out_path(args, agent.stem))
    print(f"score {trace['final']['score']:.3f}")
    print(out)
    return 0


# ---------------------------------------------------------------------------------- compare

def cmd_compare(args) -> int:
    from arena.games.dispatchdesk.replay import record

    agent = _agent_path(args.agent)
    field = [(agent.stem, agent)] + [(n, _reference_path(n)) for n in args.against]
    seeds = list(range(args.first_seed, args.first_seed + args.seeds))
    print(f"{args.game}, seeds {seeds[0]} to {seeds[-1]}\n")
    width = max(len(n) for n, _ in field)
    print(f"{'agent':<{width}}  " + "  ".join(f"{s:>6}" for s in seeds) + "    mean")
    problems = []
    for name, path in field:
        scores = []
        for s in seeds:
            try:
                scores.append(record(args.game, s, path, agent_name=name)["final"]["score"])
            except Exception as e:               # noqa: BLE001  keep the table, note the hole
                scores.append(float("nan"))
                problems.append(f"  {name} on seed {s} raised {type(e).__name__}: {e}")
        mean = sum(x for x in scores if x == x) / max(1, sum(1 for x in scores if x == x))
        print(f"{name:<{width}}  " + "  ".join(f"{x:6.3f}" for x in scores) + f"   {mean:6.3f}")
    if problems:
        print("\nnan means the agent raised. In the competition that is a fault, and the fourth "
              "fault in one shift forfeits it:")
        for line in problems[:5]:
            print(line)
    planner, careful, keyword = _reference(args.game)
    print(f"\nOn {args.game} the references score about: careful {careful:.2f}, heuristic {keyword:.2f}, "
          f"random 0.00 over many seeds; the perfect-information planner ceiling is {planner:.2f}. "
          "Five seeds is noisy; use it for direction, not for proof.")
    return 0


# -------------------------------------------------------------------------------------- main

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="codefest", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def common(p, agent_default="agent.py"):
        p.add_argument("agent", nargs="?", default=agent_default, help="your agent file")
        p.add_argument("--game", default=GAME, help=f"env id (default {GAME})")
        p.add_argument("--seed", type=int, default=SEED, help=f"shift to play (default {SEED})")

    p = sub.add_parser("play", help="play one shift and draw it")
    common(p)
    p.add_argument("--out", help="where to write the replay HTML")
    p.add_argument("--no-replay", action="store_true", help="print the score only")
    p.set_defaults(fn=cmd_play)

    p = sub.add_parser("validate", help="the competition's game, 45 s limit and fault rule, on your laptop")
    common(p)
    p.add_argument("--render", action="store_true", help="print every board and every reply")
    p.set_defaults(fn=cmd_validate)

    p = sub.add_parser("replay", help="draw a shift")
    common(p)
    p.add_argument("--out", help="where to write the replay HTML")
    p.set_defaults(fn=cmd_replay)

    p = sub.add_parser("compare", help="your agent next to the reference policies")
    common(p)
    p.add_argument("--seeds", type=int, default=5, help="how many shifts (default 5)")
    p.add_argument("--first-seed", type=int, default=1, help="first seed (default 1)")
    p.add_argument("--against", nargs="*", default=["dd_careful", "heuristic_agent"],
                   choices=REFERENCES, help="reference policies to include")
    p.set_defaults(fn=cmd_compare)

    args = ap.parse_args(argv)
    if getattr(args, "game", None) and args.game not in _registered_games():
        return _fail(f"unknown env id {args.game}\n"
                     f"That level has not been revealed yet, or you have not run `git pull` and "
                     f"reinstalled the wheel from harness/ (see README.md).\n"
                     f"Levels in this install: {', '.join(_registered_games())}")
    try:
        return args.fn(args)
    except KeyboardInterrupt:
        return 130
    except SystemExit:
        raise
    except ImportError as e:
        return _fail(f"{e}\n\nThe harness needs textarena. Install it with:\n"
                     f"    pip install textarena==0.7.3")


if __name__ == "__main__":
    sys.exit(main())
