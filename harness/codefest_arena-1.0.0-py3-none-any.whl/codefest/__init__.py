"""Local harness for the IFS codefest agent competition.

Four commands, all against DispatchDesk on your own machine:

    codefest play       play one shift and draw it
    codefest validate   the same check the competition server runs on every push
    codefest replay     draw a shift you have already played
    codefest compare    your agent next to the reference policies

The model is not reachable from here. See the README in your team repository.
"""

__version__ = "1.0.0"
