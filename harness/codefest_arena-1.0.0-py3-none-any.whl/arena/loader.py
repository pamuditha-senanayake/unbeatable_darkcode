"""Load a team's agent from a Python file and run it in an isolated child process.

Agent contract (what students implement, see teams/_template/agent.py):

    class Agent:
        def __init__(self): ...
        def reset(self, game_id: str, player_id: int): ...   # optional
        def __call__(self, observation: str) -> str: ...     # required

A module-level function `agent(observation) -> str` is also accepted.

The agent runs in its own process so that a crash, an infinite loop or a
memory blow-up in one team's code cannot take down the tournament runner.
The parent enforces a per-move wall-clock timeout; on timeout the child is
killed and the move is recorded as a forfeit.
"""
from __future__ import annotations

import importlib.util
import multiprocessing as mp
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Optional, Tuple

_CTX = mp.get_context("spawn")  # identical behaviour on Windows / Linux / macOS


def load_agent_object(agent_path: str):
    """Import agent.py from an arbitrary path and return a callable agent object."""
    path = Path(agent_path).resolve()
    if path.is_dir():
        path = path / "agent.py"
    if not path.exists():
        raise FileNotFoundError(f"Agent file not found: {path}")
    # Let the team's file import siblings (helpers.py next to agent.py).
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(f"team_agent_{abs(hash(str(path)))}", path)
    module = importlib.util.module_from_spec(spec)
    # Register the module before executing it, as a normal import would: pydantic, dataclasses and
    # typing.get_type_hints resolve postponed annotations (`from __future__ import annotations`)
    # through sys.modules[cls.__module__], and an unregistered module leaves every model
    # "not fully defined" although the same file imports fine on its own.
    sys.modules[spec.name] = module
    try:
        spec.loader.exec_module(module)  # type: ignore[union-attr]
    except BaseException:
        sys.modules.pop(spec.name, None)
        raise
    if hasattr(module, "Agent"):
        return module.Agent()
    if hasattr(module, "agent") and callable(module.agent):
        return module.agent
    raise AttributeError(f"{path} must define a class `Agent` with __call__(observation) or a function `agent(observation)`.")


def _worker(agent_path: str, conn, quiet: bool):
    if quiet:  # keep student prints out of the tournament console; they still go to the per-agent log
        log_path = Path(agent_path).resolve()
        log_path = (log_path if log_path.is_dir() else log_path.parent) / "agent_stdout.log"
        sys.stdout = sys.stderr = open(log_path, "a", encoding="utf-8", buffering=1)
    try:
        agent = load_agent_object(agent_path)
    except Exception:
        conn.send(("init_error", traceback.format_exc()))
        return
    conn.send(("ready", None))
    while True:
        try:
            msg = conn.recv()
        except (EOFError, OSError):
            return
        kind = msg[0]
        if kind == "stop":
            return
        try:
            if kind == "reset":
                fn = getattr(agent, "reset", None)
                if callable(fn):
                    fn(msg[1], msg[2])
                conn.send(("ok", None))
            elif kind == "act":
                out = agent(msg[1])
                conn.send(("ok", out if isinstance(out, str) else str(out)))
        except Exception:
            conn.send(("error", traceback.format_exc()))


class AgentProcess:
    """A team agent living in a child process, restarted automatically after a crash/timeout."""

    def __init__(self, name: str, agent_path: str, quiet: bool = True, startup_timeout: float = 60.0):
        self.name = name
        self.agent_path = str(agent_path)
        self.quiet = quiet
        self.startup_timeout = startup_timeout
        self._proc: Optional[mp.Process] = None
        self._conn = None
        self.init_error: Optional[str] = None

    # -- lifecycle -----------------------------------------------------------
    def start(self) -> bool:
        self.stop()
        parent, child = _CTX.Pipe()
        self._proc = _CTX.Process(target=_worker, args=(self.agent_path, child, self.quiet), daemon=True)
        self._proc.start()
        child.close()
        self._conn = parent
        if parent.poll(self.startup_timeout):
            kind, payload = parent.recv()
            if kind == "ready":
                self.init_error = None
                return True
            self.init_error = payload
        else:
            self.init_error = f"agent did not initialise within {self.startup_timeout}s"
        self.stop()
        return False

    def alive(self) -> bool:
        return self._proc is not None and self._proc.is_alive() and self._conn is not None

    def stop(self):
        if self._conn is not None:
            try:
                self._conn.send(("stop",))
            except Exception:
                pass
            try:
                self._conn.close()
            except Exception:
                pass
        if self._proc is not None and self._proc.is_alive():
            self._proc.join(timeout=1.0)
            if self._proc.is_alive():
                self._proc.kill()
                self._proc.join(timeout=2.0)
        self._proc, self._conn = None, None

    def _kill(self):
        if self._proc is not None and self._proc.is_alive():
            self._proc.kill()
            self._proc.join(timeout=2.0)
        self._proc, self._conn = None, None

    # -- requests ------------------------------------------------------------
    def _request(self, msg: tuple, timeout: float) -> Tuple[str, Optional[str], float]:
        """Returns (status, payload, elapsed). status in ok | error | timeout | dead."""
        if not self.alive() and not self.start():
            return "dead", self.init_error, 0.0
        t0 = time.perf_counter()
        try:
            self._conn.send(msg)
            if not self._conn.poll(timeout):
                self._kill()
                return "timeout", f"no response within {timeout}s", time.perf_counter() - t0
            kind, payload = self._conn.recv()
        except (EOFError, OSError, BrokenPipeError) as e:
            self._kill()
            return "dead", f"agent process died: {e}", time.perf_counter() - t0
        return kind, payload, time.perf_counter() - t0

    def reset(self, game_id: str, player_id: int, timeout: float = 30.0):
        return self._request(("reset", game_id, player_id), timeout)

    def act(self, observation: str, timeout: float):
        return self._request(("act", observation), timeout)

    def __del__(self):
        try:
            self.stop()
        except Exception:
            pass


# --------------------------------------------------------------------------- HTTP option
def is_remote_spec(spec) -> bool:
    """True for the container form of a participant: "http://host:8000" or {"url": "..."}."""
    if isinstance(spec, dict):
        return "url" in spec
    return isinstance(spec, str) and spec.startswith(("http://", "https://"))


def make_agent(name: str, spec, **kwargs):
    """Build the right handle for a participant spec.

    spec may be:
        "teams/team_a/agent.py"                        -> AgentProcess (local child process)
        {"path": "teams/team_a/agent.py"}              -> AgentProcess
        "http://team-a:8000" / {"url": "http://..."}   -> RemoteAgent (team container)
    Both handles expose start/reset/act/stop/alive/.name/.init_error with identical semantics.
    """
    if is_remote_spec(spec):
        from arena.remote_agent import RemoteAgent  # local import keeps loader importable everywhere
        url = spec["url"] if isinstance(spec, dict) else spec
        return RemoteAgent(name, url, **kwargs)
    path = spec["path"] if isinstance(spec, dict) else spec
    return AgentProcess(name, path, **kwargs)
