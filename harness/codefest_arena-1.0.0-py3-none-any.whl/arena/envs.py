"""Environment factory: prefer TextArena, fall back to the built-in local games."""
from __future__ import annotations

import os
from typing import Tuple

from arena.local_envs import LOCAL_REGISTRY

# How many players each TextArena env id needs. Extend as you add games.
TEXTARENA_PLAYERS = {
    "TicTacToe-v0": 2, "ConnectFour-v0": 2, "ConnectFour-v0-blind": 2, "Nim-v0": 2, "Nim-v0-medium": 2,
    "Othello-v0-small": 2, "Othello-v0": 2, "KuhnPoker-v0": 2, "KuhnPoker-v0-medium": 2,
    "LiarsDice-v0-small": 2, "LiarsDice-v0": 2, "SimpleNegotiation-v0": 2, "Battleship-v0": 2,
    "SpellingBee-v0": 2, "Poker-v0-small": 2,
    "Mastermind-v0": 1, "Mastermind-v0-hard": 1, "Wordle-v0": 1, "Sudoku-v0-easy": 1,
    "Minesweeper-v0-small": 1, "TowerOfHanoi-v0": 1, "GuessTheNumber-v0": 1,
    # DispatchDesk; arena.games registers these with TextArena on import.
    "DispatchDesk-L1": 1, "DispatchDesk-L2": 1,
}


def textarena_available() -> bool:
    if os.environ.get("ARENA_FORCE_LOCAL") == "1":
        return False
    try:
        import textarena  # noqa: F401
        return True
    except Exception:
        return False


def num_players(env_id: str) -> int:
    if env_id in TEXTARENA_PLAYERS:
        return TEXTARENA_PLAYERS[env_id]
    if env_id in LOCAL_REGISTRY:
        return LOCAL_REGISTRY[env_id][1]
    raise KeyError(f"Unknown env id '{env_id}'. Add it to arena/envs.py:TEXTARENA_PLAYERS.")


def make_env(env_id: str) -> Tuple[object, str]:
    """Return (env, backend) where backend is 'textarena' or 'local'.

    TextArena's `make` already applies LLMObservationWrapper + ActionFormattingWrapper
    for the default env ids, so get_observation() yields a plain string.
    """
    if textarena_available():
        import textarena as ta
        import arena.games  # noqa: F401  - registers the custom env ids before ta.make
        return ta.make(env_id=env_id), "textarena"
    if env_id in LOCAL_REGISTRY:
        return LOCAL_REGISTRY[env_id][0](), "local"
    raise RuntimeError(
        f"TextArena is not installed and '{env_id}' has no built-in fallback. "
        f"Run `pip install textarena==0.7.3` or pick one of: {sorted(LOCAL_REGISTRY)}")
