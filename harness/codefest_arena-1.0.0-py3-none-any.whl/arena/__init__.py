"""Codefest agent-competition harness built on top of TextArena.

Modules:
    envs        - create a game environment (TextArena, or built-in fallback games)
    loader      - load a team's agent from a Python file
    runner      - play one match with per-move timeouts and crash isolation
    tournament  - schedule a round robin (with seat swapping) and single-player seeds
    scoring     - turn match results into per-game and overall leaderboards
    cli         - `python -m arena ...` entry point
"""

__version__ = "0.1.0"
