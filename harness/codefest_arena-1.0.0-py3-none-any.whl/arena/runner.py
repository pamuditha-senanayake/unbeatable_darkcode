"""Play a single match between AgentProcess handles on one environment."""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Dict, List, Optional

from arena.envs import make_env, num_players
from arena.loader import AgentProcess

# Reward (TextArena convention) -> human-readable outcome
OUTCOME_WIN, OUTCOME_LOSS, OUTCOME_DRAW = "win", "loss", "draw"


@dataclass
class MatchResult:
    match_id: str
    env_id: str
    backend: str
    seed: int
    players: Dict[int, str]                 # player_id -> agent name
    rewards: Dict[int, float]               # player_id -> reward (TextArena convention)
    outcomes: Dict[int, str]                # win / loss / draw / forfeit-timeout / forfeit-crash / forfeit-invalid
    reasons: Dict[int, str]
    turns: int
    duration_s: float
    forfeited_by: Optional[int] = None
    forfeit_kind: Optional[str] = None      # timeout | crash | dead | max_steps
    invalid_moves: Dict[int, bool] = field(default_factory=dict)
    move_times: Dict[int, List[float]] = field(default_factory=dict)
    log_path: Optional[str] = None
    faults: Dict[int, int] = field(default_factory=dict)   # timeouts/crashes absorbed as `fault_action` ticks

    def to_json(self) -> dict:
        d = asdict(self)
        # JSON keys must be strings
        for k in ("players", "rewards", "outcomes", "reasons", "invalid_moves", "move_times", "faults"):
            d[k] = {str(pid): v for pid, v in d[k].items()}
        return d


def _outcomes_from_rewards(rewards: Dict[int, float], n: int) -> Dict[int, str]:
    if n == 1:
        r = rewards.get(0, 0)
        return {0: "solved" if r >= 1 else ("failed" if r <= -1 else "partial")}
    best = max(rewards.values())
    worst = min(rewards.values())
    if best == worst:
        return {pid: OUTCOME_DRAW for pid in rewards}
    return {pid: (OUTCOME_WIN if r == best else OUTCOME_LOSS) for pid, r in rewards.items()}


def _write_live(path: Optional[Path], payload: dict) -> None:
    """Best-effort atomic write of the live match state (never lets a dashboard problem touch the match)."""
    if path is None:
        return
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        for attempt in range(6):   # Windows: a reader holding the file open fails the rename briefly
            try:
                tmp.replace(path)
                break
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(0.02 * (attempt + 1))
    except Exception:  # noqa: BLE001
        pass


_BOARD_HEAD = re.compile(r"=== \d\d:\d\d \| tick \d+/\d+")


def _last_board(obs: str, limit: int = 8000) -> str:
    """The observation from its last board header on (DispatchDesk), else its tail - what a live viewer sees."""
    last = None
    for last in _BOARD_HEAD.finditer(obs):
        pass
    tail = obs[last.start():] if last else obs[-limit:]
    return tail[:limit]


def play_match(
    env_id: str,
    agents: Dict[int, AgentProcess],
    seed: int,
    match_id: str = "match",
    per_move_timeout: float = 30.0,
    max_steps: int = 400,
    log_dir: Optional[Path] = None,
    render: bool = False,
    live_path: Optional[Path] = None,
    fault_action: Optional[str] = None,
    max_faults: int = 3,
) -> MatchResult:
    n = num_players(env_id)
    assert set(agents) == set(range(n)), f"{env_id} needs players {list(range(n))}, got {list(agents)}"

    env, backend = make_env(env_id)
    env.reset(num_players=n, seed=seed)

    trajectory: List[dict] = []
    move_times: Dict[int, List[float]] = {pid: [] for pid in range(n)}
    forfeited_by: Optional[int] = None
    forfeit_kind: Optional[str] = None
    forfeit_detail = ""
    started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    live: dict = {"match_id": match_id, "env_id": env_id, "seed": seed,
                  "players": {str(pid): ag.name for pid, ag in agents.items()},
                  "started_at": started_at, "status": "running", "step": 0,
                  "last_action": None, "last_elapsed": None, "board": ""}
    _write_live(live_path, live)

    # Give stateful agents a chance to clear per-game memory.
    for pid, ag in agents.items():
        status, payload, _ = ag.reset(env_id, pid)
        if status != "ok":
            forfeited_by, forfeit_kind, forfeit_detail = pid, ("timeout" if status == "timeout" else "crash"), str(payload)
            break

    t0 = time.perf_counter()
    steps = 0
    faults: Dict[int, int] = {pid: 0 for pid in range(n)}
    done = forfeited_by is not None
    while not done:
        if steps >= max_steps:
            forfeit_kind = "max_steps"
            break
        pid, obs = env.get_observation()
        status, action, elapsed = agents[pid].act(obs, per_move_timeout)
        move_times[pid].append(round(elapsed, 4))
        if status != "ok":
            kind = "timeout" if status == "timeout" else "crash"
            # Fault tolerance (config `fault_action` / `max_faults` per game): a reply that times out or
            # raises costs that tick - the game receives `fault_action` (e.g. "[wait]") - instead of the
            # whole episode. Only the (max_faults + 1)-th fault in one episode forfeits. Without
            # `fault_action` the first fault forfeits, as before.
            if fault_action is not None and faults[pid] < max_faults:
                faults[pid] += 1
                trajectory.append({"step": steps, "player": pid, "observation": obs, "action": fault_action,
                                   "status": status, "detail": str(action)[-400:], "elapsed": elapsed,
                                   "fault": faults[pid]})
                if render:
                    print(f"\n=== step {steps} | player {pid} ({agents[pid].name}) | {kind} after {elapsed:.2f}s, "
                          f"fault {faults[pid]}/{max_faults}, playing {fault_action} ===")
                action = fault_action
            else:
                forfeited_by = pid
                forfeit_kind = kind
                forfeit_detail = str(action)
                if fault_action is not None:
                    forfeit_detail = f"fault {faults[pid] + 1} of this episode (limit {max_faults}). {forfeit_detail}"
                trajectory.append({"step": steps, "player": pid, "observation": obs, "action": None,
                                   "status": status, "detail": forfeit_detail, "elapsed": elapsed})
                break
        else:
            trajectory.append({"step": steps, "player": pid, "observation": obs, "action": action, "elapsed": elapsed})
        if render:
            print(f"\n=== step {steps} | player {pid} ({agents[pid].name}) | {elapsed:.2f}s ===\n{obs}\n--> {action}")
        done, _info = env.step(action=action)
        steps += 1
        if live_path is not None:
            live.update({"step": steps, "player": pid, "last_action": action, "last_elapsed": round(elapsed, 2),
                         "board": _last_board(obs), "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
            _write_live(live_path, live)

    duration = time.perf_counter() - t0

    # ---- resolve rewards -------------------------------------------------
    reasons: Dict[int, str] = {}
    invalid: Dict[int, bool] = {}
    if forfeited_by is not None:
        # Forfeit: the offender loses, everyone else wins (2P). Single-player: score 0.
        if n == 1:
            rewards = {0: 0.0}
        else:
            rewards = {pid: (-1.0 if pid == forfeited_by else 1.0) for pid in range(n)}
        outcomes = {pid: (f"forfeit-{forfeit_kind}" if pid == forfeited_by else OUTCOME_WIN) for pid in range(n)}
        if n == 1:
            outcomes = {0: f"forfeit-{forfeit_kind}"}
        reasons = {pid: f"Player {forfeited_by} ({agents[forfeited_by].name}) forfeited: {forfeit_kind}. {forfeit_detail[-400:]}"
                   for pid in range(n)}
    elif forfeit_kind == "max_steps":
        rewards = {pid: 0.0 for pid in range(n)}
        outcomes = {pid: OUTCOME_DRAW for pid in range(n)}
        reasons = {pid: f"Runner step cap ({max_steps}) reached; declared a draw." for pid in range(n)}
    else:
        rewards, game_info = env.close()
        rewards = {int(k): float(v) for k, v in (rewards or {}).items()}
        for pid in range(n):
            rewards.setdefault(pid, 0.0)
            gi = (game_info or {}).get(pid, {}) if isinstance(game_info, dict) else {}
            reasons[pid] = str(gi.get("reason", ""))
            invalid[pid] = bool(gi.get("invalid_move", False))
        outcomes = _outcomes_from_rewards(rewards, n)
        for pid in range(n):
            if invalid.get(pid) and outcomes[pid] in (OUTCOME_LOSS, "partial", "failed"):
                outcomes[pid] = "forfeit-invalid"

    result = MatchResult(
        match_id=match_id, env_id=env_id, backend=backend, seed=seed,
        players={pid: ag.name for pid, ag in agents.items()},
        rewards=rewards, outcomes=outcomes, reasons=reasons, turns=steps,
        duration_s=round(duration, 3), forfeited_by=forfeited_by, forfeit_kind=forfeit_kind,
        invalid_moves=invalid, move_times=move_times, faults=faults,
    )

    if log_dir is not None:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        path = log_dir / f"{match_id}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"result": result.to_json(), "trajectory": trajectory}, f, indent=1, ensure_ascii=False)
        result.log_path = str(path)
    if live_path is not None:
        live.update({"status": "done", "outcomes": {str(k): v for k, v in outcomes.items()},
                     "rewards": {str(k): v for k, v in rewards.items()},
                     "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
        _write_live(live_path, live)
    return result
