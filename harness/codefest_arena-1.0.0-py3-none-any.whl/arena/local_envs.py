"""Built-in fallback games that mirror TextArena's interface and action formats.

These exist so the tournament machinery can be tested (and students can run
their agents) on a machine with no TextArena install and no network.  They
copy the *observation contract* of TextArena's default wrappers:

    player_id, observation_str = env.get_observation()
    done, info = env.step(action_str)
    rewards, game_info = env.close()

and the same bracketed action syntax as the corresponding TextArena game:

    ConnectFour  ->  [col 3]  or  [3]
    Nim          ->  [pile_index quantity]   e.g. [1 3]
    Mastermind   ->  [1 2 3 4]

Invalid-move policy mirrors TextArena's TwoPlayerState/SinglePlayerState with
error_allowance=1: the first invalid move gets a warning and a retry, the
second consecutive one loses the game (2P) or ends it (1P).
"""
from __future__ import annotations

import random
import re
from typing import Dict, List, Optional, Tuple

GAME_ID = -1


class _BaseLocalEnv:
    num_players_required: int = 2
    error_allowance: int = 1

    def __init__(self):
        self.state_obs: Dict[int, List[str]] = {}
        self.rewards: Optional[Dict[int, float]] = None
        self.game_info: Dict[int, dict] = {}
        self.current_player_id = 0
        self.done = False
        self.turn = 0
        self.error_count = 0
        self.made_invalid_move = False

    # -- helpers shared by all local games -------------------------------
    def _standard_reset(self, num_players: int, seed: Optional[int]):
        assert num_players == self.num_players_required, (
            f"{type(self).__name__} needs {self.num_players_required} players, got {num_players}")
        self.rng = random.Random(seed)
        self.state_obs = {pid: [] for pid in range(num_players)}
        self.full_obs = {pid: [] for pid in range(num_players)}
        self.game_info = {pid: {"role": f"Player {pid}", "invalid_move": False, "turn_count": 0}
                          for pid in range(num_players)}
        self.rewards = None
        self.current_player_id = 0
        self.done = False
        self.turn = 0
        self.error_count = 0
        self.made_invalid_move = False

    def _add_obs(self, message: str, to_id: int = -1, from_id: int = GAME_ID):
        recipients = list(self.state_obs) if to_id == -1 else [to_id]
        sender = "GAME" if from_id == GAME_ID else f"Player {from_id}"
        for pid in recipients:
            self.state_obs[pid].append(f"[{sender}] {message}")

    def get_observation(self) -> Tuple[int, str]:
        """Like TextArena's LLMObservationWrapper: the FULL history for this player, one message per line."""
        pid = self.current_player_id
        self.full_obs[pid].extend(self.state_obs[pid])
        self.state_obs[pid] = []
        return pid, "\n" + "\n".join(self.full_obs[pid])

    def close(self):
        return self.rewards, self.game_info

    def _set_invalid_move(self, reason: str):
        if self.error_allowance > self.error_count:
            self.error_count += 1
            self.made_invalid_move = True
            self._add_obs(f"Player {self.current_player_id} attempted an invalid move. Reason: {reason} "
                          f"Please resubmit a valid move and remember to follow the game rules to avoid penalties.",
                          to_id=self.current_player_id)
        else:
            self._on_invalid_forfeit(reason)

    def _finish_step(self, rotate: bool = True):
        if not self.made_invalid_move:
            self.error_count = 0
            self.turn += 1
            self.game_info[self.current_player_id]["turn_count"] += 1
        if self.done:
            return True, {}
        if rotate and not self.made_invalid_move and self.num_players_required == 2:
            self.current_player_id = 1 - self.current_player_id
            self.error_count = 0
        self.made_invalid_move = False
        return self.done, {}


class _TwoPlayerLocalEnv(_BaseLocalEnv):
    num_players_required = 2

    def _set_winner(self, pid: int, reason: str):
        self.rewards = {pid: 1, 1 - pid: -1}
        for p in range(2):
            self.game_info[p]["reason"] = reason
        self.done = True

    def _set_draw(self, reason: str):
        self.rewards = {0: 0, 1: 0}
        for p in range(2):
            self.game_info[p]["reason"] = reason
        self.done = True

    def _on_invalid_forfeit(self, reason: str):
        cp = self.current_player_id
        self.rewards = {cp: -1, 1 - cp: 1}
        for p in range(2):
            self.game_info[p]["reason"] = reason
        self.game_info[cp]["invalid_move"] = True
        self.done = True


# ---------------------------------------------------------------------------
# Connect Four (mirrors textarena/envs/ConnectFour)
# ---------------------------------------------------------------------------
class LocalConnectFourEnv(_TwoPlayerLocalEnv):
    def __init__(self, num_rows: int = 6, num_cols: int = 7):
        super().__init__()
        self.num_rows, self.num_cols = num_rows, num_cols

    def reset(self, num_players: int = 2, seed: Optional[int] = None):
        self._standard_reset(num_players, seed)
        self.board = [["." for _ in range(self.num_cols)] for _ in range(self.num_rows)]
        for pid in range(2):
            sym = "X" if pid == 0 else "O"
            self._add_obs(
                f"You are Player {pid} in Connect Four. Your disc symbol: {sym}. "
                f"The game board has {self.num_rows} rows and {self.num_cols} columns. "
                f"Players take turns dropping their disc into one of the columns (0 to {self.num_cols - 1}). "
                f"First to connect four discs vertically, horizontally, or diagonally wins. "
                f"On your turn, select the column number in the format '[col x]', e.g. '[col 3]'.",
                to_id=pid)
        self._add_obs("Current Board:\n" + self._render())

    def _render(self) -> str:
        head = " ".join(str(c) for c in range(self.num_cols))
        return head + "\n" + "-" * (self.num_cols * 2 - 1) + "\n" + "\n".join(" ".join(r) for r in self.board)

    def step(self, action: str):
        cp = self.current_player_id
        self._add_obs(action, from_id=cp)
        m = re.search(r".*\[(?:col\s*)?(\d+)\].*", action or "", re.IGNORECASE | re.DOTALL)
        if not m:
            self._set_invalid_move("The move format is invalid. Use '[col x]'.")
            return self._finish_step()
        col = int(m.group(1))
        if not 0 <= col < self.num_cols:
            self._set_invalid_move(f"Column {col} is out of range.")
            return self._finish_step()
        if self.board[0][col] != ".":
            self._set_invalid_move(f"Column {col} is full.")
            return self._finish_step()
        row = max(r for r in range(self.num_rows) if self.board[r][col] == ".")
        sym = "X" if cp == 0 else "O"
        self.board[row][col] = sym
        self._add_obs(f"Player {cp} dropped their disc ({sym}) into column {col}.")
        if self._wins(row, col, sym):
            self._set_winner(cp, f"Player {cp} wins by connecting four!")
        elif all(self.board[0][c] != "." for c in range(self.num_cols)):
            self._set_draw("The game is a draw.")
        else:
            self._add_obs("Current Board:\n" + self._render())
        return self._finish_step()

    def _wins(self, row: int, col: int, sym: str) -> bool:
        for (dr, dc) in ((0, 1), (1, 0), (1, 1), (1, -1)):
            total = 1
            for sgn in (1, -1):
                r, c = row + dr * sgn, col + dc * sgn
                while 0 <= r < self.num_rows and 0 <= c < self.num_cols and self.board[r][c] == sym:
                    total += 1
                    r += dr * sgn
                    c += dc * sgn
            if total >= 4:
                return True
        return False


# ---------------------------------------------------------------------------
# Nim (mirrors textarena/envs/Nim) -- last player to remove a stone wins
# ---------------------------------------------------------------------------
class LocalNimEnv(_TwoPlayerLocalEnv):
    def __init__(self, piles: Optional[List[int]] = None):
        super().__init__()
        self.initial_piles = list(piles) if piles else [3, 4, 5]

    def reset(self, num_players: int = 2, seed: Optional[int] = None):
        self._standard_reset(num_players, seed)
        self.piles = self.initial_piles.copy()
        for pid in range(2):
            self._add_obs(
                f"You are Player {pid} in Nim. There are several piles of stones. On your turn remove any "
                f"positive number of stones from exactly one pile. The player who removes the last stone wins. "
                f"Submit your move as '[pile_index quantity]', e.g. '[1 3]' removes 3 stones from pile 1.",
                to_id=pid)
        self._add_obs("Current Pile:\n" + self._render())

    def _render(self) -> str:
        return "\n".join(f"  pile {i}: {n}" for i, n in enumerate(self.piles))

    def step(self, action: str):
        cp = self.current_player_id
        self._add_obs(action, from_id=cp)
        m = re.search(r"\[\s*(\d+)\s+(\d+)\s*\]", (action or "").strip())
        if not m:
            self._set_invalid_move("The move format is invalid. Use '[pile_index quantity]'.")
        else:
            idx, qty = int(m.group(1)), int(m.group(2))
            if not 0 <= idx < len(self.piles):
                self._set_invalid_move(f"Pile index {idx} is out of range.")
            elif qty <= 0:
                self._set_invalid_move("Quantity must be positive.")
            elif self.piles[idx] < qty:
                self._set_invalid_move(f"Cannot remove {qty} from pile {idx} (has {self.piles[idx]}).")
            else:
                self.piles[idx] -= qty
                self._add_obs(f"Player {cp} removed {qty} stone(s) from pile {idx}.")
        self._add_obs("Current Pile:\n" + self._render())
        if all(p == 0 for p in self.piles):
            self._set_winner(cp, f"Player {cp} took the last stone and wins!")
        return self._finish_step()


# ---------------------------------------------------------------------------
# Mastermind (mirrors textarena/envs/Mastermind) -- single player
# ---------------------------------------------------------------------------
class LocalMastermindEnv(_BaseLocalEnv):
    num_players_required = 1

    def __init__(self, code_length: int = 4, num_numbers: int = 6, max_turns: int = 20,
                 duplicate_numbers: bool = False):
        super().__init__()
        self.code_length, self.num_numbers = code_length, num_numbers
        self.max_turns, self.duplicate_numbers = max_turns, duplicate_numbers

    def reset(self, num_players: int = 1, seed: Optional[int] = None):
        self._standard_reset(num_players, seed)
        pool = list(range(1, self.num_numbers + 1))
        self.secret = self.rng.choices(pool, k=self.code_length) if self.duplicate_numbers \
            else self.rng.sample(pool, k=self.code_length)
        self.history: List[dict] = []
        rep = "may contain repeats" if self.duplicate_numbers else "contains no duplicates"
        self._add_obs(
            f"You are playing Mastermind. Guess the secret code of {self.code_length} numbers between 1 and "
            f"{self.num_numbers} (the code {rep}). After each guess you get feedback: black pegs = correct number in "
            f"the correct position, white pegs = correct number in the wrong position. You have {self.max_turns} "
            f"turns. Submit guesses as '[1 2 3 4]'.", to_id=0)

    def _set_outcome(self, reward: float, reason: str):
        self.rewards = {0: reward}
        self.game_info[0]["reason"] = reason
        self.done = True

    def _pct(self) -> float:
        if not self.history:
            return 0.0
        h = self.history[-1]
        return (h["black"] + 0.5 * h["white"]) / self.code_length

    def _on_invalid_forfeit(self, reason: str):
        self.rewards = {0: self._pct()}
        self.game_info[0]["reason"] = reason
        self.game_info[0]["invalid_move"] = True
        self.done = True

    def step(self, action: str):
        self._add_obs(action, from_id=0)
        m = re.search(r"\[(\d+(?:\s+\d+)*)\]", action or "")
        if not m:
            self._set_invalid_move("Use the format '[1 2 3 4]'.")
            return self._finish_step(rotate=False)
        guess = [int(x) for x in m.group(1).split()]
        if len(guess) != self.code_length:
            self._set_invalid_move(f"Guess must have exactly {self.code_length} numbers.")
        elif any(g < 1 or g > self.num_numbers for g in guess):
            self._set_invalid_move(f"Numbers must be between 1 and {self.num_numbers}.")
        elif not self.duplicate_numbers and len(set(guess)) != len(guess):
            self._set_invalid_move("Duplicates are not allowed.")
        elif guess in [h["guess"] for h in self.history]:
            self._set_invalid_move(f"You already guessed {guess}.")
        else:
            black, white = self._evaluate(guess)
            self.history.append({"guess": guess, "black": black, "white": white})
            if black == self.code_length:
                self._set_outcome(1.0, f"Congratulations! You cracked the code in {len(self.history)} guesses.")
            else:
                self._add_obs(f"Guess {m.group(1)}: {black} black peg(s), {white} white peg(s).")
                if self.turn + 1 >= self.max_turns:
                    self._set_outcome(self._pct(), f"Turn limit reached. Completion {self._pct() * 100:.1f}%.")
        return self._finish_step(rotate=False)

    def _evaluate(self, guess: List[int]) -> Tuple[int, int]:
        secret, g = list(self.secret), list(guess)
        black = 0
        for i in range(self.code_length):
            if g[i] == secret[i]:
                black += 1
                secret[i] = g[i] = None
        white = 0
        for i in range(self.code_length):
            if g[i] is not None and g[i] in secret:
                white += 1
                secret[secret.index(g[i])] = None
        return black, white


# Registry: env id -> (factory, num_players). IDs intentionally match TextArena's.
LOCAL_REGISTRY = {
    "ConnectFour-v0": (lambda: LocalConnectFourEnv(6, 7), 2),
    "Nim-v0": (lambda: LocalNimEnv([3, 4, 5]), 2),
    "Nim-v0-medium": (lambda: LocalNimEnv([4, 2, 3, 7]), 2),
    "Mastermind-v0": (lambda: LocalMastermindEnv(4, 6, 20, False), 1),
    "Mastermind-v0-hard": (lambda: LocalMastermindEnv(4, 8, 30, False), 1),
}
