"""Load `.env` from the repo root into the process environment (stdlib only).

The harness and the anchor agents read the shared LLM gateway settings from the
environment (`ARENA_LLM_BASE_URL`, `ARENA_LLM_API_KEY`, `ARENA_LLM_MODEL`). On the
cluster those come from a Kubernetes Secret; on a laptop they come from `.env`, which
is git-ignored. `arena.cli.main` calls `load_dotenv()` before any agent process is
spawned, so local child processes (`AgentProcess`) inherit the values.

Rules, kept deliberately close to python-dotenv's defaults so a `.env` written for
one tool works for the other:

* `KEY=value` per line; blank lines and lines starting with `#` are ignored;
  an optional leading `export ` is accepted.
* Values may be single- or double-quoted; quotes are stripped, and inside double
  quotes `\\n`, `\\t`, `\\"` and `\\\\` are unescaped. Unquoted values have inline
  `# comments` removed and surrounding whitespace trimmed.
* Variables already present in the environment win (`override=False`), so a value
  set by the shell, CI or a container Secret is never clobbered by the file.
* `ARENA_ENV_FILE` points at a different file (absolute, or relative to the repo root).
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict, Optional

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PATH = ROOT / ".env"

_LINE = re.compile(r"""^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$""")
_DQ_ESCAPES = {"n": "\n", "t": "\t", "r": "\r", '"': '"', "\\": "\\"}


def _unquote(raw: str) -> str:
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "\"'":
        body = raw[1:-1]
        if raw[0] == '"':
            body = re.sub(r"\\(.)", lambda m: _DQ_ESCAPES.get(m.group(1), "\\" + m.group(1)), body)
        return body
    # unquoted: strip an inline comment (`#` preceded by whitespace) and trailing space
    return re.split(r"\s+#", raw, maxsplit=1)[0].strip()


def parse_dotenv(text: str) -> Dict[str, str]:
    """Parse .env text into a dict. Malformed lines are skipped, never fatal."""
    out: Dict[str, str] = {}
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        m = _LINE.match(line)
        if not m:
            continue
        out[m.group(1)] = _unquote(m.group(2))
    return out


def load_dotenv(path: Optional[str | os.PathLike] = None, override: bool = False) -> Dict[str, str]:
    """Load `path` (default: `ARENA_ENV_FILE` or `<repo>/.env`) into os.environ.

    Returns the variables that were actually applied. A missing file is not an error:
    the harness runs fine without LLM settings (only `agents/llm_agent.py` and student
    LLM agents need them, and they fall back to random play when unset).
    """
    if path is None:
        env_file = os.environ.get("ARENA_ENV_FILE")
        path = (ROOT / env_file) if env_file and not Path(env_file).is_absolute() else (env_file or DEFAULT_PATH)
    path = Path(path)
    if not path.is_file():
        return {}
    values = parse_dotenv(path.read_text(encoding="utf-8-sig"))  # -sig: tolerate a Windows BOM
    applied: Dict[str, str] = {}
    for k, v in values.items():
        if override or k not in os.environ:
            os.environ[k] = v
            applied[k] = v
    return applied
