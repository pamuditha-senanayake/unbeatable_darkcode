"""Replay a DispatchDesk shift into a self-contained HTML dashboard.

    python -m arena.games.dispatchdesk.replay --seed 7
    python -m arena.games.dispatchdesk.replay --seed 7 --agent teams/my_team/agent.py
    python -m arena.games.dispatchdesk.replay --game DispatchDesk-v0-mystery --seed 3 --json

TextArena's own `SimpleRenderWrapper` puts `get_board_str()` in a `rich` panel in the
terminal, which re-wraps the board's fixed-width columns and has no notion of the shift
clock. This tool instead records the whole shift - including the hidden state the player
never sees - and writes one HTML file you can open in a browser or put on a projector.

The dashboard is an ORGANISER view: it shows true zone / skill / priority next to what the
agent had been told, which is the quickest way to see why an agent lost points. Do not hand
it to teams for a seed they will be scored on.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

ROOT = Path(__file__).resolve().parents[3]
TEMPLATE = Path(__file__).resolve().parent / "replay_template.html"


def _load_agent(path: Path):
    sys.path.insert(0, str(ROOT / "agents"))
    sys.path.insert(0, str(path.parent))
    spec = importlib.util.spec_from_file_location(path.stem, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod   # as a normal import would; postponed annotations resolve through it
    try:
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    except BaseException:
        sys.modules.pop(spec.name, None)
        raise
    return mod.Agent


def _unwrap(env):
    while hasattr(env, "env"):
        env = env.env
    return env


def _tech_state(e) -> List[Dict[str, Any]]:
    return [{"tid": t.tid, "activity": t.activity, "zone": t.zone, "dest": t.dest,
             "job": t.current_job, "busy_until": t.busy_until} for t in e.scn.techs]


def _segments(samples: List[Dict[str, Any]], tids: List[str]) -> Dict[str, List[Dict[str, Any]]]:
    """Run-length encode the per-minute samples into one timeline per technician."""
    out: Dict[str, List[Dict[str, Any]]] = {tid: [] for tid in tids}
    for tid in tids:
        track = [(s["minute"], next(t for t in s["techs"] if t["tid"] == tid)) for s in samples]
        for minute, st in track:
            key = (st["activity"], st["zone"], st["dest"], st["job"])
            segs = out[tid]
            if segs and segs[-1]["key"] == list(key):
                segs[-1]["end"] = minute + 1
            else:
                segs.append({"key": list(key), "activity": st["activity"], "zone": st["zone"],
                             "dest": st["dest"], "job": st["job"], "start": minute, "end": minute + 1})
        for s in out[tid]:
            s.pop("key")
    return out


def record(env_id: str, seed: int, agent_path: Optional[Path],
           actions: Optional[List[str]] = None, agent_name: Optional[str] = None) -> Dict[str, Any]:
    """Play one shift and return the full trace.

    Either an agent file drives the shift, or `actions` (the replies recorded in a match
    trajectory) are replayed verbatim. The environment is deterministic per seed, so replaying
    a recorded match reproduces it exactly - including invalid moves and forfeits - without
    running the agent (or paying for its LLM calls) again. That is how the run dashboard
    (arena/dashboard.py) turns every tournament match into a visual replay.
    """
    from arena.envs import make_env
    from arena.games.dispatchdesk import scenario as sc

    env, _ = make_env(env_id)
    env.reset(num_players=1, seed=seed)
    e = _unwrap(env)

    agent = None
    if actions is None and agent_path is not None:
        agent = _load_agent(agent_path)()
        if hasattr(agent, "reset"):
            agent.reset(env_id, 0)
    scripted = list(actions) if actions is not None else None

    # Sample every simulated minute by driving the env's own advance one minute at a time.
    # This only wraps the method, the simulation itself is untouched.
    def money() -> Dict[str, float]:
        return {"earned": round(e.earned, 1), **{k: round(v, 1) for k, v in e.costs.items()}}

    samples: List[Dict[str, Any]] = [{"minute": e.now, "techs": _tech_state(e), **money()}]
    original_advance = e._advance

    def advance(until: int):
        while e.now < until:
            original_advance(e.now + 1)
            samples.append({"minute": e.now, "techs": _tech_state(e), **money()})

    e._advance = advance

    def job_rows() -> List[Dict[str, Any]]:
        rows = []
        for j in e.scn.jobs:
            if j.jid not in e.delivered:
                continue
            rows.append({
                "jid": j.jid, "status": j.status, "assigned_to": j.assigned_to,
                "known_zone": j.known_zone, "known_skill": j.known_skill,
                "known_priority": j.known_priority, "dispatch_zone": j.dispatch_zone,
                "completed_at": j.completed_at, "earned": round(j.earned, 1),
            })
        return rows

    def score_so_far() -> float:
        mv = e.scn.max_value
        return 0.0 if mv <= 0 else max(0.0, min(1.0, (e.earned - sum(e.costs.values())) / mv))

    ticks: List[Dict[str, Any]] = []
    done = False
    while not done:
        _pid, obs = env.get_observation()
        frame = {
            "tick": e.tick + 1, "now": e.now, "clock": sc.clock(e.now),
            "events": list(e.events),
            "new_messages": [{"jid": e.jobs[j].jid, "clock": sc.clock(e.jobs[j].arrival),
                              "sender": e.jobs[j].sender, "text": e.jobs[j].text}
                             for j in e._just_delivered],
            "jobs": job_rows(), "techs": _tech_state(e),
            "costs": {k: round(v, 1) for k, v in e.costs.items()},
            "earned": round(e.earned, 1), "score": round(score_so_far(), 3),
            "obs_chars": len(obs),
        }
        if scripted is not None:
            # replay: the recorded reply for this step; None (the agent crashed / timed out at this
            # point in the real match) or an exhausted script falls back to [wait]
            reply = scripted.pop(0) if scripted else None
            reply = reply if isinstance(reply, str) and reply else "[wait]"
        else:
            reply = agent(obs) if agent is not None else "[wait]"
        frame["reply"] = reply
        ticks.append(frame)
        done, _ = env.step(reply)

    _pid, obs = env.get_observation()
    rewards, _info = env.close()
    real = [j for j in e.scn.jobs if j.kind == "real"]
    finished = [j for j in real if j.status == "done"]

    trace = {
        "meta": {
            "env_id": env_id, "seed": seed,
            "agent": agent_name or (agent_path.relative_to(ROOT).as_posix() if agent_path
                                    else ("recorded match" if actions is not None else "wait-only")),
            "ticks": e.scn.ticks, "tick_minutes": e.scn.tick_minutes,
            "shift_end": e.scn.shift_end, "hard_stop": e.scn.hard_stop,
            "mystery": e.scn.mystery, "max_value": round(e.scn.max_value, 1),
            "tiers": e.scn.tiers,
            "priority_value": dict(e.scn.values),
            "score": round(float(rewards[0]), 3),
            # the shift's world (levels 3+ play on "metro"); `zone_positions` is the replay's
            # schematic, which the template used to hard-code for the six-zone world
            "world": e.scn.world.name, "paraphrase": e.scn.paraphrase,
            "zones": list(e.scn.world.zones),
            "travel": {a: {b: e.scn.world.travel_minutes(a, b) for b in e.scn.world.zones}
                       for a in e.scn.world.zones},
            "zone_positions": {z: list(p) for z, p in e.scn.world.positions.items()},
            "customers": [{"name": c.name, "zone": c.zone, "aliases": list(c.aliases),
                           "tier": c.tier} for c in e.scn.world.customers],
            "constants": {"travel_cost_per_min": 0.5, "overtime_cost_per_min": 1.0,
                          "question_fee": 5, "wrong_merge_penalty": 15, "wasted_visit_min": 15,
                          "late_factor": 0.5},
        },
        "techs": [{"tid": t.tid, "name": t.name, "skills": list(t.skills),
                   "start_zone": start["zone"], "shift_end": t.shift_end}
                  for t, start in zip(e.scn.techs, samples[0]["techs"])],
        "jobs": [{"jid": j.jid, "kind": j.kind, "arrival": j.arrival,
                  "clock": sc.clock(j.arrival), "sender": j.sender, "text": j.text,
                  "customer": j.customer.name if j.customer else None,
                  "true_zone": j.zone, "true_skill": j.skill, "true_priority": j.priority,
                  "duration": j.duration, "dup_of": j.dup_of,
                  "value": round(j.base_value, 1),
                  "base_priority": j.base_priority,
                  "sla_deadline": j.sla_deadline(e.scn.shift_end) if j.priority else None,
                  "tier": j.customer.tier if j.customer else None}
                 for j in e.scn.jobs],
        "timeline": _segments(samples, [t.tid for t in e.scn.techs]),
        # one value per simulated minute, so the dashboard can show value and cost
        # accumulating continuously - including the overtime tail after the last command
        "series": {"minute0": samples[0]["minute"],
                   **{k: [s[k] for s in samples]
                      for k in ("earned", "travel", "overtime", "fees", "penalties")}},
        "ticks": ticks,
        "final": {
            "score": round(float(rewards[0]), 3), "earned": round(e.earned, 1),
            "max_value": round(e.scn.max_value, 1),
            "costs": {k: round(v, 1) for k, v in e.costs.items()},
            "real": len(real), "done": len(finished),
            "on_time": len([j for j in finished
                            if j.completed_at <= j.sla_deadline(e.scn.shift_end)]),
            "missed": [{"jid": j.jid, "priority": j.priority, "skill": j.skill, "zone": j.zone}
                       for j in real if j.status != "done"],
            "summary": obs[obs.rindex("=== SHIFT OVER"):] if "=== SHIFT OVER" in obs else "",
        },
    }
    return trace


def write_html(trace: Dict[str, Any], out: Path) -> Path:
    html = TEMPLATE.read_text(encoding="utf-8")
    # A reply containing "</script>" would otherwise close the script element and the rest of the
    # trace would be parsed as HTML (found by the kit stream with a probe agent, 2026-09-17).
    # "<\/" is a legal JSON escape that JavaScript reads back as "/", so the page is unchanged.
    payload = json.dumps(trace, ensure_ascii=False, separators=(",", ":")).replace("</", r"<\/")
    if "__TRACE__" not in html:
        raise SystemExit(f"{TEMPLATE} has no __TRACE__ placeholder")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html.replace("__TRACE__", payload), encoding="utf-8")
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--game", default="DispatchDesk-v0")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--agent", default="agents/heuristic_agent.py",
                    help="agent file to drive the shift, or 'none' for a do-nothing shift")
    ap.add_argument("--out", help="output .html (default results/replay/<game>_seed<N>.html)")
    ap.add_argument("--json", action="store_true", help="also write the raw trace as .json")
    ap.add_argument("--from-match", help="replay a recorded match: results/<run>/matches/<match_id>.json "
                                         "(env id, seed and the replies come from the file; --game/--seed/--agent are ignored)")
    args = ap.parse_args(argv)

    if args.from_match:
        rec = json.loads(Path(args.from_match).read_text(encoding="utf-8"))
        res, traj = rec["result"], rec["trajectory"]
        actions = [s.get("action") for s in traj]
        name = res["players"].get("0", "player")
        trace = record(res["env_id"], int(res["seed"]), None, actions=actions, agent_name=name)
        out = Path(args.out).resolve() if args.out else ROOT / "results" / "replay" / f"{res['match_id']}.html"
    else:
        agent_path = None if args.agent.lower() == "none" else (ROOT / args.agent).resolve()
        if agent_path is not None and not agent_path.exists():
            raise SystemExit(f"no such agent: {agent_path}")
        trace = record(args.game, args.seed, agent_path)
        out = Path(args.out).resolve() if args.out else ROOT / "results" / "replay" / f"{args.game}_seed{args.seed}.html"
    write_html(trace, out)
    print(f"score {trace['final']['score']:.3f}  "
          f"({trace['final']['done']}/{trace['final']['real']} jobs done, "
          f"{trace['final']['on_time']} within SLA)")
    print(f"dashboard: {out}")
    if args.json:
        jp = out.with_suffix(".json")
        jp.write_text(json.dumps(trace, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"trace:     {jp}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
