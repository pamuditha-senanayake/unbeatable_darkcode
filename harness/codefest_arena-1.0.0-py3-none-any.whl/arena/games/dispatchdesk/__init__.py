"""DispatchDesk: a field-service dispatch game for text agents (see docs/game-rules.md)."""
