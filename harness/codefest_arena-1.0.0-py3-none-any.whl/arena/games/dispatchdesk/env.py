"""DispatchDesk environment: one shift of field-service dispatching, single player.

Turn structure: the player sees the state at HH:MM, replies with up to MAX_COMMANDS bracketed
commands, and the simulation advances one tick (30 minutes). After the last tick the
technicians finish what they were given (overtime until 19:00) and the shift is scored.

Score in [0, 1] = clamp((SLA value earned - travel - overtime - fees - penalties) / max value).
"""
from __future__ import annotations

import random
import re
from typing import Any, Dict, List, Optional, Tuple

import textarena as ta

from arena.games.dispatchdesk import scenario as sc
from arena.games.dispatchdesk.scenario import Job, Scenario, Technician, clock

MAX_COMMANDS = 5
TRAVEL_COST_PER_MIN = 0.5
OVERTIME_COST_PER_MIN = 1.0
QUESTION_FEE = 5.0
WRONG_MERGE_PENALTY = 15.0
WASTED_VISIT_MIN = 15          # minutes lost on a wrong site / wrong skill / nothing-to-do visit
LATE_FACTOR = 0.5              # fraction of the value for a job finished after its SLA

_CMD_RE = re.compile(r"\[([^\[\]]+)\]")


class DispatchDeskEnv(ta.Env):
    def __init__(self, ticks: int = 18, tick_minutes: int = 30, num_techs: int = 4, num_jobs: int = 11,
                 num_dups: int = 2, num_noise: int = 1, mystery: bool = False,
                 values: Optional[Dict[int, int]] = None, tiers: Optional[bool] = None,
                 world: str = "stockholm",
                 paraphrase: bool = False, vague_rate: float = 0.5, decoy_rate: float = 0.25,
                 location_styles: Optional[List[str]] = None):
        super().__init__()
        self.cfg = dict(ticks=ticks, tick_minutes=tick_minutes, num_techs=num_techs, num_jobs=num_jobs,
                        num_dups=num_dups, num_noise=num_noise, mystery=mystery,
                        values=values, tiers=tiers, world=world,
                        paraphrase=paraphrase, vague_rate=vague_rate, decoy_rate=decoy_rate,
                        location_styles=location_styles)
        self.mystery = mystery

    # ------------------------------------------------------------------ lifecycle
    def reset(self, num_players: int, seed: Optional[int] = None):
        self.state = ta.SinglePlayerState(num_players=num_players, seed=seed, max_turns=self.cfg["ticks"] + 1)
        self.rng = random.Random(seed if seed is not None else random.randrange(1 << 30))
        self.scn: Scenario = sc.generate(self.rng, **self.cfg)
        self.jobs: Dict[str, Job] = {j.jid: j for j in self.scn.jobs}
        self.techs: Dict[str, Technician] = {t.tid: t for t in self.scn.techs}
        self.now = 0                               # minutes after 08:00
        self.tick = 0
        self.costs = {"travel": 0.0, "overtime": 0.0, "fees": 0.0, "penalties": 0.0}
        self.earned = 0.0
        self.delivered: List[str] = []             # job ids already shown to the player
        self._just_delivered: List[str] = []       # shown in full in the next board
        self.events: List[str] = []                # since the last observation
        self.pending_answers: List[Tuple[str, str]] = []   # (jid, text) delivered next tick
        self.wrong_merges: set = set()
        self.state.reset(game_state={"tick": 0}, player_prompt_function=self._prompt)
        self._deliver_new_messages()
        self._publish_board()

    def get_board_str(self) -> str:
        return self._board()

    # ------------------------------------------------------------------ prompt / board
    def _prompt(self, player_id: int, game_state: Dict[str, Any]) -> str:
        s = self.scn
        lines = [
            "You are the dispatcher at NordServ Field Service for one shift, 08:00-17:00.",
            f"The shift is played in {s.ticks} ticks of {s.tick_minutes} minutes. Each tick you see new customer messages, "
            f"the open jobs, your technicians, and you reply with up to {MAX_COMMANDS} commands in square brackets.",
            "",
            "GOAL: complete as much SLA value as possible while spending little on travel, overtime, questions and mistakes.",
            f"  Job value by true priority: P1 = {s.values[1]}, P2 = {s.values[2]}, P3 = {s.values[3]}.",
            "  SLA: P1 must be finished within 2 h of the message, P2 within 4 h, P3 by 17:00. "
            f"A job finished after its SLA earns {int(LATE_FACTOR * 100)}%; an unfinished job earns 0.",
            f"  Costs: travel {TRAVEL_COST_PER_MIN:g} per minute, overtime {OVERTIME_COST_PER_MIN:g} per minute after a technician's shift end "
            f"(nobody works past {clock(s.hard_stop)}), question fee {QUESTION_FEE:g}, wrong merge {WRONG_MERGE_PENALTY:g}.",
            "  Final score = (value earned - costs) / total value of all real jobs, clipped to [0, 1].",
            "",
            "THE MESSAGES are written by customers: urgency is implied, the site may be named, hinted at with a nickname, or "
            "missing, the fault may be ambiguous, some messages repeat a job already reported, and some are not service "
            "requests at all. Priority is never shown - you infer it (or ask).",
            "",
            "COMMANDS (several per reply, each in its own brackets):",
            "  [assign T2 J7 Kista]   queue job J7 for technician T2, travelling to zone Kista. The zone is required unless the "
            "game already knows it (shown in the job list). Jobs run in queue order; a wrong zone, wrong skill or a non-job "
            f"costs the technician {WASTED_VISIT_MIN} min plus travel, after which the true zone / skill is revealed.",
            "  [unassign J7]          take J7 out of a queue (not possible once work has started).",
            "  [ask J7 location] | [ask J7 problem] | [ask J7 urgency]   the customer answers next tick; fee "
            f"{QUESTION_FEE:.0f} each.",
            "  [merge J9 J7]          declare J9 a repeat of J7. Correct: J9 closes. Wrong: penalty and both stay open.",
            "  [ignore J9]            close J9 for good (use for messages that are not service requests).",
            "  [wait]                 do nothing this tick.",
            "Malformed replies (no valid command) count as invalid moves; two in a row forfeit the game.",
            "",
            "ZONES and travel minutes:",
        ]
        zs = s.world.zones
        lines.append("  " + " ".join(f"{z:>11}" for z in [""] + zs))
        for a in zs:
            lines.append("  " + f"{a:>11}" + " ".join(f"{s.world.travel_minutes(a, b):>11}" for b in zs))
        lines.append("")
        lines.append("CUSTOMER DIRECTORY (name | zone | also called):")
        for c in s.world.customers:
            row = f"  {c.name:<27} {c.zone:<11} {', '.join(c.aliases)}"
            lines.append(row)
        lines += ["", "TECHNICIANS (id, name, skills, start zone, shift end):"]
        for t in s.techs:
            lines.append(f"  {t.tid} {t.name:<6} {'/'.join(t.skills):<26} starts at {t.zone:<11} shift ends {clock(t.shift_end)}")
        return "\n".join(lines)

    def _job_row(self, j: Job) -> str:
        zone = j.known_zone or "?"
        skill = j.known_skill or "?"
        prio = f"P{j.known_priority}" if j.known_priority else "?"
        if j.status == "in_progress":
            t = self.techs[j.assigned_to]
            st = f"in progress: {t.tid} until {clock(t.busy_until)}"
        elif j.status == "assigned":
            t = self.techs[j.assigned_to]
            if t.current_job == j.jid and t.activity == "travel":
                st = f"{t.tid} travelling, arrives {clock(t.busy_until)}"
            elif t.current_job == j.jid:
                st = f"{t.tid} at wrong site, re-routing to {t.dest} at {clock(t.busy_until)}"
            else:
                st = f"queued for {t.tid} (position {t.queue.index(j.jid) + 1})"
        else:
            st = "UNASSIGNED"
        return f"  {j.jid:<4} {clock(j.arrival)}  from {j.sender[:28]:<28}  zone {zone:<11} skill {skill:<13} prio {prio:<3} {st}"

    def _tech_row(self, t: Technician) -> str:
        if t.activity == "idle":
            where = f"at {t.zone}"
            doing = "idle"
        elif t.activity == "travel":
            where = f"-> {t.dest}"
            doing = f"travelling for {t.current_job}, arrives {clock(t.busy_until)}"
        elif t.activity == "work":
            where = f"at {t.zone}"
            doing = f"working on {t.current_job} until {clock(t.busy_until)}"
        else:
            where = f"at {t.zone}"
            doing = f"on site ({t.current_job}) until {clock(t.busy_until)}"
        q = ", ".join(t.queue) if t.queue else "-"
        off = " OFF SHIFT (overtime)" if self.now >= t.shift_end else ""
        return f"  {t.tid} {t.name:<6} {'/'.join(t.skills):<26} {where:<15} {doing:<40} queue: {q}{off}"

    def _board(self) -> str:
        c = self.costs
        total_cost = sum(c.values())
        lines = [f"=== {clock(self.now)} | tick {self.tick + 1}/{self.scn.ticks} | earned {self.earned:.0f} | costs {total_cost:.0f} "
                 f"(travel {c['travel']:.0f}, overtime {c['overtime']:.0f}, fees {c['fees']:.0f}, penalties {c['penalties']:.0f}) ==="]
        if self.events:
            lines.append("Events:")
            lines += [f"  {e}" for e in self.events]
        new = [self.jobs[j] for j in self._just_delivered]
        if new:
            lines.append("New messages:")
            for j in new:
                lines.append(f"  {j.jid} {clock(j.arrival)} from {j.sender}: \"{j.text}\"")
        open_jobs = [self.jobs[j] for j in self.delivered if self.jobs[j].status in ("open", "assigned", "in_progress")]
        lines.append("Open jobs:" if open_jobs else "Open jobs: none")
        lines += [self._job_row(j) for j in open_jobs]
        lines.append("Technicians:")
        lines += [self._tech_row(t) for t in self.scn.techs]
        lines.append(f"Your commands (max {MAX_COMMANDS}), e.g. [assign T1 J3 Solna] [ask J4 location] [merge J5 J2] [ignore J6] [wait]:")
        return "\n".join(lines)

    def _publish_board(self):
        self.state.add_observation(message=self._board(), observation_type=ta.ObservationType.GAME_BOARD)
        self.events = []
        self._just_delivered = []

    # ------------------------------------------------------------------ step
    def step(self, action: str) -> Tuple[bool, ta.Info]:
        self.state.add_observation(from_id=self.state.current_player_id, message=action,
                                   observation_type=ta.ObservationType.PLAYER_ACTION)
        # An empty bracket pair - "[]", "[ ]" - is not a command. Dropping it here rather than
        # in _execute keeps `parts[0]` safe; the fuzzer found that it used to raise IndexError,
        # and arena/tournament.py does not wrap play_match, so one such reply from one student
        # agent would have aborted the whole tournament run.
        cmds = [c for c in (m.group(1).strip() for m in _CMD_RE.finditer(action)) if c]
        if not cmds:
            self.state.set_invalid_move(reward=0.0, reason="No command in square brackets found.")
            return self.state.step()

        feedback: List[str] = []
        valid = 0
        for i, cmd in enumerate(cmds):
            if i >= MAX_COMMANDS:
                feedback.append(f"[{cmd}] ignored: more than {MAX_COMMANDS} commands.")
                break
            ok, msg = self._execute(cmd)
            valid += int(ok)
            if msg:
                feedback.append(msg)
        if valid == 0:
            self.state.set_invalid_move(reward=0.0, reason="None of your commands was valid. " + " ".join(feedback))
            return self.state.step()
        if feedback:
            self.state.add_observation(message="\n".join(feedback), observation_type=ta.ObservationType.GAME_ACTION_DESCRIPTION)

        # advance one tick
        self._advance(self.now + self.scn.tick_minutes)
        self.tick += 1
        self._deliver_answers()
        if self.tick >= self.scn.ticks:
            self._finish()
        else:
            self._deliver_new_messages()
            self._publish_board()
        return self.state.step()

    # ------------------------------------------------------------------ commands
    def _execute(self, cmd: str) -> Tuple[bool, str]:
        parts = cmd.split()
        verb = parts[0].lower()
        args = parts[1:]
        try:
            if verb == "wait":
                return True, ""
            if verb == "assign":
                return self._cmd_assign(args)
            if verb == "unassign":
                return self._cmd_unassign(args)
            if verb == "ask":
                return self._cmd_ask(args)
            if verb == "merge":
                return self._cmd_merge(args)
            if verb == "ignore":
                return self._cmd_ignore(args)
        except _Reject as r:
            return False, f"[{cmd}] rejected: {r}"
        return False, f"[{cmd}] rejected: unknown command."

    def _job(self, jid: str, open_only: bool = True) -> Job:
        jid = jid.upper()
        if jid not in self.jobs or jid not in self.delivered:
            raise _Reject(f"no job {jid}.")
        j = self.jobs[jid]
        if open_only and j.status not in ("open", "assigned", "in_progress"):
            raise _Reject(f"{jid} is already {j.status}.")
        return j

    def _tech(self, tid: str) -> Technician:
        tid = tid.upper()
        if tid not in self.techs:
            raise _Reject(f"no technician {tid}.")
        return self.techs[tid]

    def _cmd_assign(self, args: List[str]) -> Tuple[bool, str]:
        if len(args) < 2:
            raise _Reject("usage [assign T1 J3 Zone].")
        t = self._tech(args[0])
        j = self._job(args[1])
        zone = j.known_zone
        if len(args) >= 3:
            z = self.scn.world.match_zone(args[2])
            if z is None:
                raise _Reject(f"unknown zone '{args[2]}'. Zones: {', '.join(self.scn.world.zones)}.")
            zone = zone or z
        if zone is None:
            raise _Reject(f"{j.jid} has no confirmed zone; add one, e.g. [assign {t.tid} {j.jid} Solna], or [ask {j.jid} location].")
        if j.status == "in_progress":
            raise _Reject(f"{j.jid} is already being worked on by {j.assigned_to}.")
        if j.status == "assigned":
            old = self.techs[j.assigned_to]
            if old.current_job == j.jid:
                raise _Reject(f"{old.tid} is already travelling to {j.jid}; [unassign {j.jid}] first if you must.")
            if j.jid in old.queue:
                old.queue.remove(j.jid)
        j.status, j.assigned_to, j.dispatch_zone = "assigned", t.tid, zone
        t.queue.append(j.jid)
        return True, ""

    def _cmd_unassign(self, args: List[str]) -> Tuple[bool, str]:
        if not args:
            raise _Reject("usage [unassign J3].")
        j = self._job(args[0])
        if j.status == "open":
            raise _Reject(f"{j.jid} is not assigned.")
        if j.status == "in_progress":
            raise _Reject(f"{j.jid} is already in progress.")
        t = self.techs[j.assigned_to]
        if j.jid in t.queue:                  # still queued: just drop it
            t.queue.remove(j.jid)
        if t.current_job == j.jid:
            # `current_job` outlives the job itself: a wrong-skill visit hands the job back
            # as `open` (so it can be assigned again) while the technician is still standing
            # at the wrong site with `activity == "wasted"`. Only a technician who is really
            # on the road can be recalled to their destination.
            if t.activity == "travel":        # recall; the drive so far is a sunk cost
                t.activity, t.zone, t.dest = "idle", t.dest, None
                t.busy_until = self.now
                self.events.append(f"{clock(self.now)} {t.name} ({t.tid}) recalled; continues from {t.zone}.")
            else:                             # stays where they are, idle once the delay is over
                t.dest = None
            t.current_job = None
        j.status, j.assigned_to, j.dispatch_zone = "open", None, None
        return True, ""

    def _cmd_ask(self, args: List[str]) -> Tuple[bool, str]:
        if len(args) < 2 or args[1].lower() not in ("location", "problem", "urgency"):
            raise _Reject("usage [ask J3 location|problem|urgency].")
        j = self._job(args[0])
        topic = args[1].lower()
        self.costs["fees"] += QUESTION_FEE
        self.pending_answers.append((j.jid, topic))
        return True, ""

    def _cmd_merge(self, args: List[str]) -> Tuple[bool, str]:
        if len(args) < 2:
            raise _Reject("usage [merge J9 J7] (J9 is the repeat).")
        a = self._job(args[0])
        b = self._job(args[1])
        if a.jid == b.jid:
            raise _Reject("cannot merge a job with itself.")
        dup, orig = (a, b) if a.dup_of == b.jid else ((b, a) if b.dup_of == a.jid else (None, None))
        if dup is None:
            key = frozenset((a.jid, b.jid))
            if key not in self.wrong_merges:
                self.costs["penalties"] += WRONG_MERGE_PENALTY
                self.wrong_merges.add(key)
            return True, f"[merge {a.jid} {b.jid}] wrong: the customers confirm these are separate issues (penalty {WRONG_MERGE_PENALTY:.0f})."
        self._close_dup(dup, orig)
        return True, f"{dup.jid} merged into {orig.jid}."

    def _cmd_ignore(self, args: List[str]) -> Tuple[bool, str]:
        if not args:
            raise _Reject("usage [ignore J3].")
        j = self._job(args[0])
        if j.status == "in_progress":
            raise _Reject(f"{j.jid} is already in progress.")
        if j.status == "assigned":
            self._cmd_unassign([j.jid])
        j.status = "closed"
        return True, ""

    def _close_dup(self, dup: Job, orig: Job):
        if dup.status == "assigned":
            self._cmd_unassign([dup.jid])
        dup.status = "merged"
        if orig.known_zone is None and dup.known_zone:
            orig.known_zone = dup.known_zone

    # ------------------------------------------------------------------ simulation
    def _advance(self, until: int):
        while self.now < until:
            self.now += 1
            for t in self.scn.techs:
                self._tick_tech(t)

    def _en_route(self, j: Job) -> bool:
        """True while a technician is actually on their way to this job (not merely queued)."""
        if j.assigned_to is None:
            return False
        return self.techs[j.assigned_to].current_job == j.jid



    def _charge_minute(self, t: Technician, travelling: bool):
        if travelling:
            self.costs["travel"] += TRAVEL_COST_PER_MIN
        if self.now > t.shift_end:
            self.costs["overtime"] += OVERTIME_COST_PER_MIN

    def _tick_tech(self, t: Technician):
        now = self.now
        if t.activity != "idle":
            self._charge_minute(t, t.activity == "travel")
            if now < t.busy_until:
                return
            # activity finished
            if t.activity == "travel":
                t.zone, t.dest = t.dest, None
                self._arrive(t)
                return
            if t.activity == "work":
                self._complete(t)
            elif t.activity == "wasted" and t.dest is not None:      # wrong site: travel on to the real one
                t.activity, t.busy_until = "travel", now + self.scn.world.travel_minutes(t.zone, t.dest)
                return
            t.activity, t.current_job = "idle", None
        if t.activity == "idle" and now >= self.scn.hard_stop:
            t.queue.clear()
            return
        if t.activity == "idle" and t.queue and now < self.scn.hard_stop:
            jid = t.queue.pop(0)
            j = self.jobs[jid]
            if j.status != "assigned" or j.assigned_to != t.tid:
                return
            t.current_job = jid
            target = j.known_zone or j.dispatch_zone
            if t.zone == target:
                self._arrive(t)
            else:
                t.activity, t.dest, t.busy_until = "travel", target, now + self.scn.world.travel_minutes(t.zone, target)

    def _arrive(self, t: Technician):
        j = self.jobs[t.current_job]
        now = self.now
        if j.status != "assigned" or j.assigned_to != t.tid:      # unassigned / merged while travelling
            t.activity, t.current_job = "idle", None
            return
        if j.kind == "noise":
            # record the customer's real zone, not wherever the technician happened to be sent
            j.status, j.known_zone = "closed", (j.zone or t.zone)
            self.events.append(f"{clock(now)} {t.name} ({t.tid}) at {t.zone} for {j.jid}: nothing to fix - the customer never asked for a visit. {WASTED_VISIT_MIN} min lost.")
            self._waste(t, j)
            return
        if j.kind == "dup":
            orig = self.jobs[j.dup_of]
            self.events.append(f"{clock(now)} {t.name} ({t.tid}) at {t.zone} for {j.jid}: same issue as {orig.jid}"
                               f"{' (already done)' if orig.status == 'done' else ''}. {WASTED_VISIT_MIN} min lost.")
            j.status = "merged"
            self._close_dup(j, orig)
            self._waste(t, j)
            return
        if t.zone != j.zone:
            j.known_zone = j.zone
            self.events.append(f"{clock(now)} {t.name} ({t.tid}) at {t.zone} for {j.jid}: wrong site! The customer is in {j.zone}. "
                               f"{t.name} heads there after {WASTED_VISIT_MIN} min.")
            t.activity, t.busy_until = "wasted", now + WASTED_VISIT_MIN
            t.dest = j.zone
            j.dispatch_zone = j.zone
            # after the wasted minutes, travel on (handled in _tick_tech via 'wasted' -> travel)
            return
        if j.skill not in t.skills:
            j.known_skill, j.known_zone = j.skill, j.zone
            j.status, j.assigned_to, j.dispatch_zone = "open", None, None
            article = "an" if j.skill[0].lower() in "aeiou" else "a"
            self.events.append(f"{clock(now)} {t.name} ({t.tid}) at {t.zone} for {j.jid}: this is {article} {j.skill} job, {t.name} cannot fix it. "
                               f"{j.jid} is unassigned again. {WASTED_VISIT_MIN} min lost.")
            t.activity, t.busy_until = "wasted", now + WASTED_VISIT_MIN
            t.dest = None
            return
        j.status, j.known_zone, j.known_skill = "in_progress", j.zone, j.skill
        t.activity, t.busy_until = "work", now + j.duration
        self.events.append(f"{clock(now)} {t.name} ({t.tid}) started {j.jid} at {t.zone}, expected done {clock(t.busy_until)}.")

    def _waste(self, t: Technician, j: Job):
        t.activity, t.busy_until, t.dest = "wasted", self.now + WASTED_VISIT_MIN, None

    def _complete(self, t: Technician):
        j = self.jobs[t.current_job]
        j.status, j.completed_at = "done", self.now
        j.known_priority = j.priority
        deadline = j.sla_deadline(self.scn.shift_end)
        on_time = self.now <= deadline
        # base_value, not value: the payout and the denominator always agree
        # (see scenario.Scenario.max_value).
        j.earned = j.base_value * (1.0 if on_time else LATE_FACTOR)
        self.earned += j.earned
        self.events.append(f"{clock(self.now)} {t.name} ({t.tid}) finished {j.jid} (P{j.priority}, SLA {clock(deadline)}): "
                           f"{'on time' if on_time else 'LATE'}, +{j.earned:.0f}.")

    # ------------------------------------------------------------------ messages
    def _deliver_new_messages(self):
        for j in self.scn.jobs:
            if j.jid in self.delivered or j.arrival > self.now:
                continue
            if j.kind == "dup" and self.jobs[j.dup_of].status in ("done",):
                j.kind, j.text = "noise", "Thanks, your technician sorted it out. All good now, just closing the loop."
                j.dup_of = None
            self.delivered.append(j.jid)
            self._just_delivered.append(j.jid)

    def _deliver_answers(self):
        for jid, topic in self.pending_answers:
            j = self.jobs[jid]
            if j.kind == "noise":
                text = sc.ANSWER_NOISE
                if j.zone:
                    j.known_zone = j.zone
            elif topic == "location":
                j.known_zone = j.zone
                text = self.rng.choice(sc.ANSWER_LOCATION).format(customer=j.customer.name, zone=j.zone)
            elif topic == "problem":
                if j.kind == "dup":
                    text = sc.ANSWER_DUP
                else:
                    j.known_skill = j.skill
                    text = sc.ANSWER_PROBLEM[j.skill]
            else:
                if j.kind == "dup":
                    text = sc.ANSWER_DUP
                else:
                    j.known_priority = j.priority
                    text = sc.ANSWER_URGENCY[j.priority]
            self.events.append(f"{clock(self.now)} Answer from {j.sender} about {j.jid} ({topic}): \"{text}\"")
        self.pending_answers = []

    # ------------------------------------------------------------------ scoring
    def _score(self) -> float:
        mv = self.scn.max_value
        if mv <= 0:
            return 0.0
        return max(0.0, min(1.0, (self.earned - sum(self.costs.values())) / mv))


    def _finish(self):
        # let the technicians finish their queues (overtime) until the hard stop
        self._advance(self.scn.hard_stop)
        score = self._score()
        real = [j for j in self.scn.jobs if j.kind == "real"]
        done = [j for j in real if j.status == "done"]
        on_time = [j for j in done if j.completed_at <= j.sla_deadline(self.scn.shift_end)]
        c = self.costs
        lines = [f"=== SHIFT OVER ({clock(self.now)}) ==="]
        if self.events:
            lines.append("Final events:")
            lines += [f"  {e}" for e in self.events]
        lines.append(f"Real jobs: {len(real)}, finished {len(done)} ({len(on_time)} within SLA). "
                     f"Value earned {self.earned:.0f} of {self.scn.max_value:.0f}.")
        lines.append(f"Costs: travel {c['travel']:.0f}, overtime {c['overtime']:.0f}, fees {c['fees']:.0f}, penalties {c['penalties']:.0f}.")
        missed = [f"{j.jid} (P{j.priority} {j.skill} at {j.zone})" for j in real if j.status != "done"]
        if missed:
            lines.append("Not completed: " + ", ".join(missed))
        lines.append(f"SCORE {score:.3f}")
        self.state.add_observation(message="\n".join(lines), observation_type=ta.ObservationType.GAME_ADMIN)
        self.state.set_outcome(reward=score, reason=f"Shift complete. Score {score:.3f} "
                               f"({len(on_time)}/{len(real)} jobs within SLA, earned {self.earned:.0f}, costs {sum(c.values()):.0f}).")


class _Reject(Exception):
    pass
