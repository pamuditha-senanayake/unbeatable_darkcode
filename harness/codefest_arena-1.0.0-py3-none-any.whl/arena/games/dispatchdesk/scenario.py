"""World data and the seeded scenario generator for DispatchDesk.

Everything random goes through the `random.Random` instance passed in, so a seed
fully determines the shift: technicians, tickets, their wording and arrival order.
"""
from __future__ import annotations

import json
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# ----------------------------------------------------------------------------- world
ZONES = ["Depot", "Kista", "Solna", "Sundbyberg", "Sodermalm", "Nacka"]

_TRAVEL_PAIRS = {
    ("Depot", "Kista"): 25, ("Depot", "Solna"): 15, ("Depot", "Sundbyberg"): 20,
    ("Depot", "Sodermalm"): 15, ("Depot", "Nacka"): 30,
    ("Kista", "Solna"): 20, ("Kista", "Sundbyberg"): 15, ("Kista", "Sodermalm"): 35, ("Kista", "Nacka"): 45,
    ("Solna", "Sundbyberg"): 10, ("Solna", "Sodermalm"): 25, ("Solna", "Nacka"): 35,
    ("Sundbyberg", "Sodermalm"): 30, ("Sundbyberg", "Nacka"): 40,
    ("Sodermalm", "Nacka"): 20,
}


def travel_minutes(a: str, b: str) -> int:
    if a == b:
        return 0
    return _TRAVEL_PAIRS.get((a, b)) or _TRAVEL_PAIRS[(b, a)]


SKILLS = ["HVAC", "refrigeration", "electrical", "IT", "lift", "plumbing"]

# Work duration in minutes per skill (chosen at random per job).
DURATIONS = {
    "HVAC": [30, 60, 60, 90], "refrigeration": [30, 60, 90], "electrical": [30, 30, 60],
    "IT": [30, 30, 60], "lift": [60, 90], "plumbing": [30, 60, 60],
}

# Priority -> (value, SLA minutes after arrival; None = end of shift 17:00)
# PRIORITY_VALUE is the v0 table and the default; a shift carries its own copy in
# `Job.values`, so a variant can widen the spread without touching v0 (see `generate`).
PRIORITY_VALUE = {1: 60, 2: 40, 3: 20}
PRIORITY_VALUE_V1 = {1: 100, 2: 40, 3: 10}
PRIORITY_SLA = {1: 120, 2: 240, 3: None}



@dataclass(frozen=True)
class Customer:
    name: str
    zone: str
    aliases: Tuple[str, ...]
    tier: str
    equipment: Tuple[str, ...]      # skills this site plausibly needs
    people: Tuple[str, ...]         # sender names


CUSTOMERS: List[Customer] = [
    Customer("Kista Logistics AB", "Kista", ("the KL warehouse", "the warehouse"), "silver",
             ("refrigeration", "electrical", "IT"), ("Lena", "Marcus")),
    Customer("Solna Health Clinic", "Solna", ("the clinic", "Solna vardcentral"), "gold",
             ("HVAC", "lift", "IT", "electrical"), ("front desk", "Dr Ekstrom")),
    Customer("Sundbyberg Bakery", "Sundbyberg", ("the bakery", "the bakery on the square"), "bronze",
             ("refrigeration", "electrical", "plumbing"), ("Hassan", "the night baker")),
    Customer("Nacka Marina Hotel", "Nacka", ("the hotel", "the Marina"), "gold",
             ("HVAC", "plumbing", "lift", "electrical"), ("reception", "Ingrid (housekeeping)")),
    Customer("Soder Data Center", "Sodermalm", ("SDC", "the server hall"), "gold",
             ("HVAC", "IT", "electrical"), ("NOC on duty", "Pavel")),
    Customer("Kista Science Tower", "Kista", ("the tower", "KST"), "silver",
             ("lift", "HVAC", "IT"), ("building manager", "Sofia")),
    Customer("Sundbyberg Municipal Pool", "Sundbyberg", ("the pool", "the swimming hall"), "silver",
             ("plumbing", "HVAC", "electrical"), ("pool staff", "Jonas")),
    Customer("Nacka Retail Park", "Nacka", ("the retail park", "NRP"), "bronze",
             ("refrigeration", "electrical", "IT"), ("store manager", "Emma")),
    Customer("Soder Brewery", "Sodermalm", ("the brewery", "the brewhouse"), "silver",
             ("refrigeration", "plumbing", "electrical"), ("Ola", "brew team")),
    Customer("Solna Office Campus", "Solna", ("the campus", "SOC building B"), "bronze",
             ("IT", "electrical", "HVAC"), ("facilities", "Karin")),
]
CUSTOMER_BY_NAME: Dict[str, Customer] = {c.name: c for c in CUSTOMERS}

TECH_NAMES = ["Amir", "Bea", "Carl", "Dana", "Elin", "Farid", "Greta", "Hugo"]


# ----------------------------------------------------------------------------- worlds
@dataclass
class World:
    """Everything about the map that a level can swap: the zones, the travel table, the
    customer directory, the technician names, and where the replay draws each zone.

    `stockholm` is the six-zone world every shift before the levels was generated on. `generate`
    consumes the RNG in the same order whichever world it is handed, so `DispatchDesk-v0` and
    `-v1` transcripts are byte-identical to what they were before worlds existed (proven over
    100 seeds in docs/notes-levels.md). Zone names are single tokens of at most 11 characters
    with distinct first four letters (the board parsers and `match_zone` rely on both); customer
    names are at most 26 characters (the directory row pads to 27 and the parser splits on two
    spaces).
    """
    name: str
    zones: List[str]
    travel: Dict[Tuple[str, str], int]          # unordered pairs, minutes
    customers: List[Customer]
    tech_names: List[str]
    positions: Dict[str, Tuple[int, int]]       # replay schematic, 0..100 canvas

    def travel_minutes(self, a: str, b: str) -> int:
        if a == b:
            return 0
        return self.travel.get((a, b)) or self.travel[(b, a)]

    def match_zone(self, text: str) -> Optional[str]:
        """The zone a player meant: exact, or the first four letters, case-insensitive."""
        t = text.strip().strip(",.").lower()
        for z in self.zones:
            if z.lower() == t or z.lower().startswith(t[:4]):
                return z
        if t in ("söder", "sodermalm", "södermalm") and "Sodermalm" in self.zones:
            return "Sodermalm"
        return None

    def customer(self, name: str) -> Customer:
        return next(c for c in self.customers if c.name == name)


STOCKHOLM = World(
    name="stockholm", zones=ZONES, travel=_TRAVEL_PAIRS, customers=CUSTOMERS, tech_names=TECH_NAMES,
    positions={"Kista": (13, 12), "Solna": (46, 19), "Sundbyberg": (17, 38),
               "Depot": (50, 50), "Sodermalm": (52, 76), "Nacka": (88, 86)},
)

# The "metro" world (level 3 and up): ten zones around a central Depot. A ring of suburbs, two
# far corners (Kista in the north-west, Nacka and Farsta in the south-east), and Lidingo an
# island reached over one bridge, so it is close to Solna and the Depot and far from everything
# else. The table is data, not a formula, so it can be tuned pair by pair.
METRO_ZONES = ["Depot", "Kista", "Sundbyberg", "Solna", "Taby", "Lidingo", "Nacka", "Farsta",
               "Sodermalm", "Bromma"]
_METRO_TRAVEL = {
    ("Depot", "Kista"): 30, ("Depot", "Sundbyberg"): 20, ("Depot", "Solna"): 20, ("Depot", "Taby"): 30,
    ("Depot", "Lidingo"): 25, ("Depot", "Nacka"): 30, ("Depot", "Farsta"): 25, ("Depot", "Sodermalm"): 20,
    ("Depot", "Bromma"): 25,
    ("Kista", "Sundbyberg"): 20, ("Kista", "Solna"): 25, ("Kista", "Taby"): 25, ("Kista", "Lidingo"): 55,
    ("Kista", "Nacka"): 50, ("Kista", "Farsta"): 45, ("Kista", "Sodermalm"): 40, ("Kista", "Bromma"): 30,
    ("Sundbyberg", "Solna"): 20, ("Sundbyberg", "Taby"): 30, ("Sundbyberg", "Lidingo"): 50,
    ("Sundbyberg", "Nacka"): 40, ("Sundbyberg", "Farsta"): 35, ("Sundbyberg", "Sodermalm"): 30,
    ("Sundbyberg", "Bromma"): 20,
    ("Solna", "Taby"): 20, ("Solna", "Lidingo"): 25, ("Solna", "Nacka"): 40, ("Solna", "Farsta"): 40,
    ("Solna", "Sodermalm"): 30, ("Solna", "Bromma"): 30,
    ("Taby", "Lidingo"): 35, ("Taby", "Nacka"): 40, ("Taby", "Farsta"): 45, ("Taby", "Sodermalm"): 40,
    ("Taby", "Bromma"): 40,
    ("Lidingo", "Nacka"): 40, ("Lidingo", "Farsta"): 50, ("Lidingo", "Sodermalm"): 45, ("Lidingo", "Bromma"): 55,
    ("Nacka", "Farsta"): 20, ("Nacka", "Sodermalm"): 25, ("Nacka", "Bromma"): 40,
    ("Farsta", "Sodermalm"): 15, ("Farsta", "Bromma"): 30,
    ("Sodermalm", "Bromma"): 25,
}
METRO_CUSTOMERS: List[Customer] = CUSTOMERS + [
    Customer("Taby Centrum Mall", "Taby", ("the mall", "Taby C"), "silver",
             ("lift", "HVAC", "electrical", "refrigeration"), ("centre management", "Viktor")),
    Customer("Taby Riding Arena", "Taby", ("the riding hall", "the stables"), "bronze",
             ("plumbing", "electrical", "HVAC"), ("Annika", "stable staff")),
    Customer("Lidingo Care Home", "Lidingo", ("the care home", "Lidingohemmet"), "gold",
             ("HVAC", "lift", "plumbing", "electrical"), ("night nurse", "Margareta")),
    Customer("Millesgarden Cafe", "Lidingo", ("the sculpture park cafe", "the cafe by the museum"), "bronze",
             ("refrigeration", "plumbing", "electrical"), ("Ebba", "kitchen")),
    Customer("Farsta Ice Rink", "Farsta", ("the rink", "the ice hall"), "silver",
             ("refrigeration", "electrical", "HVAC", "plumbing"), ("rink manager", "Tomas")),
    Customer("Farsta Grocery Depot", "Farsta", ("the grocery depot", "FGD"), "silver",
             ("refrigeration", "IT", "electrical"), ("warehouse lead", "Nour")),
    Customer("Bromma Airport Cargo", "Bromma", ("the cargo terminal", "BMA cargo"), "gold",
             ("IT", "electrical", "lift", "HVAC"), ("ops desk", "Henrik")),
    Customer("Bromma Blocks Cinema", "Bromma", ("the cinema", "the Blocks"), "bronze",
             ("HVAC", "electrical", "IT"), ("duty manager", "Alva")),
    Customer("Soder Harbour Restaurant", "Sodermalm", ("the harbour restaurant", "the quay place"), "silver",
             ("refrigeration", "plumbing", "electrical"), ("head chef", "Liam")),
    Customer("Nacka Sports Centre", "Nacka", ("the sports centre", "Nacka sim"), "silver",
             ("plumbing", "HVAC", "electrical", "lift"), ("reception desk", "Gustav")),
    Customer("Solna Stadium Catering", "Solna", ("the stadium kitchens", "the arena catering"), "silver",
             ("refrigeration", "plumbing", "electrical"), ("catering lead", "Maja")),
    Customer("Sundbyberg Print Works", "Sundbyberg", ("the print works", "the printers"), "bronze",
             ("electrical", "HVAC", "IT"), ("shift foreman", "Rasmus")),
    Customer("Kista Data Hall North", "Kista", ("the north hall", "KDH"), "gold",
             ("IT", "HVAC", "electrical"), ("NOC night", "Priya")),
]
METRO_TECH_NAMES = TECH_NAMES + ["Ida", "Kalle", "Lova", "Malin"]

METRO = World(
    name="metro", zones=METRO_ZONES, travel=_METRO_TRAVEL, customers=METRO_CUSTOMERS,
    tech_names=METRO_TECH_NAMES,
    positions={"Depot": (50, 50), "Kista": (12, 12), "Sundbyberg": (22, 36), "Solna": (46, 20),
               "Taby": (72, 6), "Lidingo": (88, 34), "Nacka": (88, 84), "Farsta": (58, 94),
               "Sodermalm": (52, 74), "Bromma": (16, 66)},
)

WORLDS: Dict[str, World] = {"stockholm": STOCKHOLM, "metro": METRO}

# ----------------------------------------------------------------------------- text
# Problem wording per skill. "clear" texts name the equipment. "vague" texts describe the
# symptom in words that a keyword matcher would attribute to the decoy skill (second element);
# a reader who thinks about the cause gets it right.
PROBLEM_TEXT: Dict[str, Dict[str, List]] = {
    "HVAC": {
        "clear": ["the air conditioning on the 3rd floor is blowing warm air",
                  "ventilation unit on the roof is rattling and the office is stuffy",
                  "the AC in the meeting rooms stopped completely",
                  "the heat pump for the west wing shows a fault and the rooms are cold"],
        "vague": [("the server room is roasting and the machines have started throttling - the network guys say their kit is fine", "IT"),
                  ("there is a puddle under the ceiling cassette in the lobby, looks like condensation, nothing to do with the pipes", "plumbing"),
                  ("every meeting room is boiling, the wall thermostats show 27 and the fans never start", "electrical"),
                  ("the operating rooms are not holding the required temperature, the plant room unit keeps cycling", "refrigeration")],
    },
    "refrigeration": {
        "clear": ["the cold room is beeping and the temperature is climbing",
                  "walk-in freezer is not holding temperature",
                  "display fridge compressor sounds wrong and it is warming up",
                  "the blast chiller trips its alarm every twenty minutes"],
        "vague": [("the lights on the cold room panel are all red and it keeps beeping, the electrician we called said it is not his thing", "electrical"),
                  ("the ice cream cabinet is standing in a puddle and everything in it is soft", "plumbing"),
                  ("the vaccine storage unit in the pharmacy reads 9 degrees and rising", "HVAC"),
                  ("our walk-in is warm, the fan inside runs but nothing gets cold", "HVAC")],
    },
    "electrical": {
        "clear": ["half the lights on the ground floor are out, breaker keeps tripping",
                  "a socket in the workshop is sparking",
                  "the main distribution board is buzzing",
                  "one phase is dead in the kitchen, half the equipment is off"],
        "vague": [("wifi, tills and the fridges on the east side all dropped at once - the same wall", "IT"),
                  ("the lift stops halfway and all the lights in the shaft go out, the lift company says it is our supply", "lift"),
                  ("the pumps in the plant room keep tripping the board, water side looks fine", "plumbing"),
                  ("the AC units all died at the same second, the panel next to them smells burnt", "HVAC")],
    },
    "IT": {
        "clear": ["the network switch in the wiring closet is dead, no internet on floor 2",
                  "the access-point controller is offline and the wifi is down",
                  "the point-of-sale terminals cannot reach the server",
                  "the core router is rebooting in a loop"],
        "vague": [("the card readers on all the doors are dead and staff are locked out, power is fine", "electrical"),
                  ("the fridge monitoring dashboard says all units offline but the fridges themselves are cold", "refrigeration"),
                  ("the lift phones and the building alarm panel both lost their connection this morning", "lift"),
                  ("nothing works on the 2nd floor, every screen says no connection but the lights are on", "electrical")],
    },
    "lift": {
        "clear": ["lift 2 is stuck between floors, nobody inside",
                  "the goods lift doors won't close",
                  "elevator is out of service, error code on the panel",
                  "the passenger lift is running but skips the 4th floor"],
        "vague": [("the goods hoist in the loading bay will not move, the display shows E47", "electrical"),
                  ("the platform between the kitchen and the delivery ramp is jammed halfway", "plumbing"),
                  ("a guest is stuck in the cabin between floors 3 and 4, the alarm button works", "electrical"),
                  ("the wheelchair ramp lift by the pool entrance stopped with someone on it", "plumbing")],
    },
    "plumbing": {
        "clear": ["a pipe burst in the staff kitchen, water on the floor",
                  "the toilets on floor 1 are backing up",
                  "no hot water anywhere in the building",
                  "the mains inlet valve is leaking into the plant room"],
        "vague": [("the sprinkler test valve keeps dripping onto the switchboard cover", "electrical"),
                  ("the dishwasher inlet is spraying water across the staff kitchen", "electrical"),
                  ("the drain in the cold room floor is overflowing, the fridge itself is fine", "refrigeration"),
                  ("there is water running down the lift shaft wall from the floor above", "lift")],
    },
}

# Urgency is conveyed by consequence rather than by adjectives; several P3 texts contain
# "urgent"/"hurry" negated, several P1 texts contain no urgency adverb at all.
URGENCY_TEXT = {
    1: ["This is really urgent, we have patients here.", "URGENT - please send someone right now.",
        "we need someone within the hour, this is critical",
        "There are 200 vaccine doses in there and we have maybe an hour before they are lost.",
        "Two hundred guests check in at 15:00 and this is the only way up.",
        "The whole warehouse is standing still, forty people waiting.",
        "Someone is inside. Please.", "It's getting worse by the minute, please hurry."],
    2: ["Can someone come today please?", "Needs sorting this morning if possible.",
        "It is affecting half the floor, would appreciate a visit today.", "please prioritise, it's disrupting work",
        "We can cope until early afternoon but not longer.", "Half the staff are working from the corridor, so today please."],
    3: ["No rush, whenever you have a slot.", "Not urgent, but please get to it before the end of the day.",
        "Whenever convenient, sometime today is fine.", "low priority, just logging it",
        "No need to hurry, it is not critical, we have a workaround.", "Definitely not urgent - end of day is fine.",
        "Not an emergency at all, just please do not forget us."],
}

# Location styles: "named" = customer named in the sender line; "alias" = only an alias in
# the text; "missing" = nothing identifies the site.
LOCATION_STYLES = ["named", "named", "alias", "alias", "alias", "missing", "missing"]

ALIAS_PHRASES = ["We are at {alias}.", "This is {alias} again.", "here at {alias}", "({alias})", "calling from {alias}"]

# Decoy place names that a matcher would take for the site.
DECOY_PLACE = ["Our driver is coming from {zone} and can let you in.", "I am at the {zone} office today but the problem is on site.",
               "Please do not send anyone to {zone} like last time, that is our other branch.", "The spare key is with our {zone} team."]

DUP_TEXT = ["hi again, still nobody here about the {hint}. any update??",
            "Following up on my earlier message - {hint} - when is someone coming?",
            "2nd message today: the {hint} problem is still ongoing. Someone said someone was on the way?",
            "Re: {hint}. Is this being handled? We have not heard back.",
            "Different person here, same building - has anyone been dispatched for the {hint}?",
            "My colleague wrote earlier about the {hint}. Adding that it is now affecting the whole floor."]

DUP_HINTS = {"HVAC": "air con", "refrigeration": "cold room / fridge", "electrical": "power issue",
             "IT": "network", "lift": "lift", "plumbing": "water"}

NOISE_TEXT = ["Thanks, the engineer fixed it yesterday, please send the invoice to accounts.",
              "Is this the number for the catering order? We need 20 sandwiches by noon.",
              "Just confirming our maintenance contract renews in October, no action needed.",
              "Hi, wrong number I think, sorry!",
              "FYI we moved reception to the east entrance. Nothing broken.",
              "Can you confirm which technician visited us last Tuesday? Need the name for the visitor log.",
              "Our lift inspection certificate expires next month - can you email a quote? No fault to report.",
              "Heads up: the server room door code changes tomorrow. Nothing is broken, just for your records."]

ANSWER_LOCATION = ["We are {customer}, in {zone}.", "{customer} - the {zone} site.", "Sorry! It's {customer} ({zone})."]
ANSWER_PROBLEM = {"HVAC": "It's the air handling / climate unit, definitely the HVAC side.",
                  "refrigeration": "It is the cold storage / refrigeration unit itself.",
                  "electrical": "An electrician is needed - it is the power supply / wiring.",
                  "IT": "It's the network equipment, an IT technician please.",
                  "lift": "It is the elevator itself, we need a lift technician.",
                  "plumbing": "It's the pipework / water side, a plumber."}
ANSWER_URGENCY = {1: "Honestly it is critical - within about two hours or we have a real problem.",
                  2: "Important but not an emergency; we need it done within a few hours.",
                  3: "Low priority. Any time before you close today is fine."}

ANSWER_NOISE = "Sorry, we did not ask for a technician. Nothing to fix here."
ANSWER_DUP = "Yes - this is the same issue we already reported earlier today."

# ----------------------------------------------------------------------------- wording banks
# Every text the generator draws comes from a bank of this shape. DEFAULT_BANK is the hand-written
# wording above (levels 1 to 3). Level 4 loads `banks/paraphrases.json`: several thousand phrasings
# generated once with the gateway (banks/generate.py, banks/PROMPT.md), reviewed by hand and
# committed, so a keyword list built from this file no longer matches the tickets. The file is not
# in the competitor kit; `load_bank` says so if it is missing. Drawing is `rng.choice` on a list,
# so a seed fixes the wording whichever bank is in use.
DEFAULT_BANK: Dict[str, object] = {
    "problem": PROBLEM_TEXT,          # skill -> {"clear": [text], "vague": [(text, decoy skill)]}
    "urgency": URGENCY_TEXT,          # priority -> [text]
    "alias_phrase": ALIAS_PHRASES,    # [text with {alias}]
    "decoy_place": DECOY_PLACE,       # [text with {zone}]
    "dup": DUP_TEXT,                  # [text with {hint}]
    "noise": NOISE_TEXT,              # [text]
}
_BANK_DIR = Path(__file__).resolve().parent / "banks"
_BANK_CACHE: Dict[str, Dict[str, object]] = {}


def load_bank(name: str = "paraphrases") -> Dict[str, object]:
    """The committed wording bank `banks/<name>.json`, with the same shape as DEFAULT_BANK."""
    if name in _BANK_CACHE:
        return _BANK_CACHE[name]
    path = _BANK_DIR / f"{name}.json"
    if not path.exists():
        raise FileNotFoundError(
            f"DispatchDesk needs the wording bank {path.name}, which is not in this install "
            f"(it is not part of the competitor kit). Expected at {path}.")
    raw = json.loads(path.read_text(encoding="utf-8"))
    bank: Dict[str, object] = {
        "problem": {skill: {"clear": list(v["clear"]), "vague": [tuple(x) for x in v["vague"]]}
                    for skill, v in raw["problem"].items()},
        "urgency": {int(k): list(v) for k, v in raw["urgency"].items()},
        "alias_phrase": list(raw["alias_phrase"]),
        "decoy_place": list(raw["decoy_place"]),
        "dup": list(raw["dup"]),
        "noise": list(raw["noise"]),
    }
    for key, v in raw.items():                    # any further per-priority bank, e.g. for a later level
        if key not in bank and key != "meta" and isinstance(v, dict):
            bank[key] = {int(k): list(x) for k, x in v.items()}
    for skill in SKILLS:
        if not bank["problem"].get(skill, {}).get("clear") or not bank["problem"][skill].get("vague"):
            raise ValueError(f"{path.name}: no problem texts for {skill}")
    _BANK_CACHE[name] = bank
    return bank


# ----------------------------------------------------------------------------- model
@dataclass
class Technician:
    tid: str
    name: str
    skills: Tuple[str, ...]
    zone: str
    shift_end: int                  # minutes after 08:00
    # runtime state (filled by the env)
    activity: str = "idle"          # idle | travel | work | wasted
    busy_until: int = 0
    dest: Optional[str] = None
    current_job: Optional[str] = None
    queue: List[str] = field(default_factory=list)


@dataclass
class Job:
    jid: str
    kind: str                       # real | dup | noise
    arrival: int                    # minutes after 08:00
    sender: str                     # the "from" line shown to the player
    text: str
    customer: Optional[Customer]
    zone: Optional[str]             # true zone (None for anonymous noise)
    skill: Optional[str]            # true skill (real jobs)
    priority: Optional[int]
    duration: int = 0
    dup_of: Optional[str] = None
    values: Dict[int, int] = field(default_factory=lambda: dict(PRIORITY_VALUE))
    # what the player has been told for sure
    known_zone: Optional[str] = None
    known_skill: Optional[str] = None
    known_priority: Optional[int] = None
    # runtime
    status: str = "open"            # open | assigned | in_progress | done | merged | closed
    assigned_to: Optional[str] = None
    dispatch_zone: Optional[str] = None
    completed_at: Optional[int] = None
    earned: float = 0.0
    # `base_priority` is the priority the job was written at, and it is what the score
    # denominator uses. `sla_from` is when this job's SLA clock started.
    base_priority: Optional[int] = None
    sla_from: Optional[int] = None

    def __post_init__(self):
        if self.base_priority is None:
            self.base_priority = self.priority
        if self.sla_from is None:
            self.sla_from = self.arrival

    @property
    def value(self) -> float:
        if self.kind != "real":
            return 0.0
        return float(self.values[self.priority])

    @property
    def base_value(self) -> float:
        """Value at the priority the job was written at - the score denominator's view."""
        if self.kind != "real":
            return 0.0
        return float(self.values[self.base_priority])

    def sla_deadline(self, shift_end: int) -> int:
        sla = PRIORITY_SLA[self.priority]
        return shift_end if sla is None else min(self.sla_from + sla, shift_end)


@dataclass
class Scenario:
    ticks: int
    tick_minutes: int
    shift_end: int                  # 17:00 = 540
    hard_stop: int                  # 19:00 = 660
    mystery: bool
    techs: List[Technician]
    jobs: List[Job]                 # sorted by arrival
    tiers: bool = False
    values: Dict[int, int] = field(default_factory=lambda: dict(PRIORITY_VALUE))
    world: World = field(default_factory=lambda: STOCKHOLM)
    paraphrase: bool = False        # level 4: wording drawn from banks/paraphrases.json
    bank: Dict[str, object] = field(default_factory=lambda: DEFAULT_BANK)

    @property
    def max_value(self) -> float:
        """Total value on offer, at the priorities the jobs were *written* at.

        The denominator is a property of the seed alone, so two agents on one seed are
        always scored against the same total.
        """
        return sum(j.base_value for j in self.jobs if j.kind == "real")


def clock(minutes: int) -> str:
    h, m = divmod(8 * 60 + minutes, 60)
    return f"{h:02d}:{m:02d}"


# ----------------------------------------------------------------------------- generator
def _sender_line(rng: random.Random, cust: Optional[Customer], style: str) -> str:
    if cust is None or style == "missing":
        return rng.choice(["unknown number", "no caller id", "web form (no company given)"])
    person = rng.choice(cust.people)
    if style == "named":
        return f"{person}, {cust.name}"
    return person   # alias style: person only, site alias is buried in the text


def _compose(rng: random.Random, cust: Optional[Customer], skill: str, priority: int,
             style: str, tiers: bool, zones: List[str] = ZONES, bank: Optional[Dict[str, object]] = None,
             vague_rate: float = 0.5, decoy_rate: float = 0.25) -> Tuple[str, bool]:
    """Return (text, vague). Vague texts read like the decoy skill to a keyword matcher."""
    bank = bank or DEFAULT_BANK
    problems = bank["problem"][skill]
    vague = rng.random() < vague_rate
    if vague:
        problem, _decoy = rng.choice(problems["vague"])
    else:
        problem = rng.choice(problems["clear"])
    worded_priority = priority
    urgency = rng.choice(bank["urgency"][worded_priority])
    problem = problem.rstrip(".")
    parts = [problem[0].upper() + problem[1:] + ("" if problem[-1] in "!?" else ".")]
    if style == "alias" and cust is not None:
        parts.insert(rng.randrange(2), rng.choice(bank["alias_phrase"]).format(alias=rng.choice(cust.aliases)))
    parts.append(urgency)
    if cust is not None and rng.random() < decoy_rate:  # a place name that is NOT the site
        decoy = rng.choice([z for z in zones if z not in (cust.zone, "Depot")])
        parts.append(rng.choice(bank["decoy_place"]).format(zone=decoy))
    if rng.random() < 0.3:
        parts[0] = parts[0].lower()
    return " ".join(parts), vague


def generate(rng: random.Random, ticks: int = 18, tick_minutes: int = 30, num_techs: int = 4,
             num_jobs: int = 11, num_dups: int = 2, num_noise: int = 1, mystery: bool = False,
             values: Optional[Dict[int, int]] = None, tiers: Optional[bool] = None,
             world: str = "stockholm", paraphrase: bool = False, vague_rate: float = 0.5,
             decoy_rate: float = 0.25, location_styles: Optional[List[str]] = None) -> Scenario:
    """Build one shift. `values` is the P1/P2/P3 table (default: the v0 one).

    `world` names the map (see `WORLDS`); the default reproduces every pre-level shift exactly.
    `paraphrase` draws every text from banks/paraphrases.json instead of the wording in this
    file; `vague_rate`, `decoy_rate` and `location_styles` are the level-4 text knobs.
    """
    w = WORLDS[world] if isinstance(world, str) else world
    bank = load_bank() if paraphrase else DEFAULT_BANK
    styles = location_styles or LOCATION_STYLES
    values = dict(values or PRIORITY_VALUE)
    tiers = mystery if tiers is None else tiers
    shift_end = ticks * tick_minutes                 # 18 x 30 = 540 -> 17:00
    hard_stop = shift_end + 120

    # --- technicians: three of them cover all six skills between them; the extra ones
    # duplicate skills and one of *those* goes home at 15:00, so no skill is ever lost early.
    skills = SKILLS[:]
    rng.shuffle(skills)
    pairs = [tuple(skills[i:i + 2]) for i in range(0, 6, 2)]
    while len(pairs) < num_techs:
        pairs.append(tuple(rng.sample(SKILLS, 2)))
    early = rng.randrange(3, num_techs) if num_techs > 3 else None
    order = list(range(num_techs))
    rng.shuffle(order)                                   # hide which tech is the "spare"
    names = rng.sample(w.tech_names, num_techs)
    techs = []
    for tid_idx, i in enumerate(order):
        zone = "Depot" if tid_idx == 0 else rng.choice(w.zones)
        end = shift_end - 120 if i == early else shift_end
        techs.append(Technician(f"T{tid_idx + 1}", names[i], pairs[i], zone, end))

    # --- real jobs
    jobs: List[Job] = []
    last_arrival_tick = max(1, min(ticks - 6, int(ticks * 0.7)))
    arrivals = [0] * min(3, num_jobs) + [rng.randrange(1, last_arrival_tick + 1) for _ in range(num_jobs - 3)]
    arrivals.sort()
    customers = rng.sample(w.customers, min(len(w.customers), num_jobs))
    while len(customers) < num_jobs:
        customers.append(rng.choice(w.customers))
    for i, (tick, cust) in enumerate(zip(arrivals, customers)):
        skill = rng.choice(cust.equipment)
        priority = rng.choices([1, 2, 3], weights=[3, 4, 3])[0]
        style = rng.choice(styles)
        text, _vague = _compose(rng, cust, skill, priority, style, tiers, w.zones, bank,
                                vague_rate, decoy_rate)
        minute = tick * tick_minutes - rng.randrange(1, tick_minutes) if tick > 0 else -rng.randrange(0, 25)
        jobs.append(Job(jid="", kind="real", arrival=minute, sender=_sender_line(rng, cust, style), text=text,
                        customer=cust, zone=cust.zone, skill=skill, priority=priority,
                        duration=rng.choice(DURATIONS[skill]), values=values))

    # --- duplicates: follow-ups to real jobs, 1-4 ticks later
    real = jobs[:]
    for orig in rng.sample(real, min(num_dups, len(real))):
        delay = rng.randrange(1, 5) * tick_minutes
        minute = orig.arrival + delay + rng.randrange(0, 10)
        if minute >= shift_end - tick_minutes:
            minute = shift_end - tick_minutes - 1
        text = rng.choice(bank["dup"]).format(hint=DUP_HINTS[orig.skill])
        style = rng.choice(["named", "alias"])
        if style == "alias":
            text += " " + rng.choice(bank["alias_phrase"]).format(alias=rng.choice(orig.customer.aliases))
        jobs.append(Job(jid="", kind="dup", arrival=minute, sender=_sender_line(rng, orig.customer, style), text=text,
                        customer=orig.customer, zone=orig.zone, skill=orig.skill, priority=orig.priority,
                        dup_of=orig, values=values))  # resolved to an id below

    # --- noise
    for _ in range(num_noise):
        cust = rng.choice(w.customers + [None] * 3)
        minute = rng.randrange(0, shift_end - tick_minutes)
        jobs.append(Job(jid="", kind="noise", arrival=minute, sender=_sender_line(rng, cust, "named" if cust else "missing"),
                        text=rng.choice(bank["noise"]), customer=cust, zone=cust.zone if cust else None,
                        skill=None, priority=None, values=values))

    jobs.sort(key=lambda j: (j.arrival, j.kind))
    for i, j in enumerate(jobs):
        j.jid = f"J{i + 1}"
    for j in jobs:
        if j.kind == "dup":
            j.dup_of = j.dup_of.jid   # type: ignore[union-attr]
    return Scenario(ticks=ticks, tick_minutes=tick_minutes, shift_end=shift_end, hard_stop=hard_stop,
                    mystery=mystery, techs=techs, jobs=jobs, tiers=tiers,
                    values=values, world=w, paraphrase=paraphrase, bank=bank)


