"""DispatchDesk, registered with TextArena on import.

`arena.envs.make_env` imports this module before calling `textarena.make`, so every env id here
can be made exactly like a stock TextArena game.

The levels in this kit:

    DispatchDesk-L1            level 1, Warm-up
    DispatchDesk-L2            level 2, Pressure

Every level takes the same commands and prints the same board, so an agent written for the first
one runs unchanged on the rest and simply scores less. Later levels are revealed as the day goes
on and arrive in your repository as a commit on `harness/`. The final round uses a variant that
is in no kit, and the rule that changes in it is written out at the top of that episode.
"""
from __future__ import annotations

try:
    import textarena as ta
    from textarena.wrappers import ActionFormattingWrapper, LLMObservationWrapper
except Exception:  # textarena not installed: the harness falls back to arena.local_envs
    ta = None

if ta is not None:
    _WRAPPERS = [LLMObservationWrapper, ActionFormattingWrapper]

    def _register(env_id: str, entry_point: str, **kwargs):
        if env_id not in ta.envs.registration.ENV_REGISTRY:
            ta.register(id=env_id, entry_point=entry_point, default_wrappers=_WRAPPERS, **kwargs)

    # v1: the same shift under capacity pressure (22 real jobs against 4 technicians, 55% of the
    # roster) and with a wider value spread, so that triage and reading urgency are worth
    # something. v0 is left exactly as it was so older runs stay comparable. Measurements and
    # the reasoning are in docs/notes-game-v1.md.
    from arena.games.dispatchdesk.scenario import PRIORITY_VALUE_V1 as _V1
    _V1_SHIFT = dict(num_jobs=22, num_dups=4, num_noise=2, values=_V1)

    # Levels (docs/game-design-v2.md, "Level contract"). One game played as five levels: same
    # commands and board everywhere, growing scale, harder text, a rule change in the final.
    # L1 is the v0 shift on the v1 value table so every level scores on one table; v0 itself
    # stays untouched as the regression oracle. L3 to L5 are PLACEHOLDERS (aliases) until the
    # real ones land; the ids are frozen so the rounds stream can build configs against them.
    _register("DispatchDesk-L1", "arena.games.dispatchdesk.env:DispatchDeskEnv",
              num_jobs=11, num_dups=2, num_noise=1, values=_V1)
    _register("DispatchDesk-L2", "arena.games.dispatchdesk.env:DispatchDeskEnv", **_V1_SHIFT)
    # L3: the metro world (10 zones, 23 customers), 8 technicians, 45 real jobs, 8 repeats and 4
    # non-requests. Same 18 ticks; the board roughly doubles. Measurements in docs/notes-levels.md.
    _L3_SHIFT = dict(num_techs=8, num_jobs=45, num_dups=8, num_noise=4, values=_V1, world="metro")
    # L4: the L3 shape with harder text. The site is missing or nicknamed more often, the fault
    # wording is vague more often and a decoy place appears more often, so an answer settles what
    # the text left open. `paraphrase=True`: every text comes from banks/paraphrases.json (5582
    # phrasings generated once with the gateway, reviewed, committed, not in the kit), so a word
    # list built from scenario.py no longer reads the tickets.
    _L4_TEXT = dict(paraphrase=True, vague_rate=0.7, decoy_rate=0.45,
                    location_styles=["named", "alias", "alias", "alias", "missing", "missing", "missing"])
